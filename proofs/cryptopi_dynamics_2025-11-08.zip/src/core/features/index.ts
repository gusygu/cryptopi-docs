// src/core/features/index.ts
export * as strAux from './str-aux';
export * as cinAux from './cin-aux';
export * as matrices from './matrices';
export * as meaAux from './mea-aux';
export * as hooks from './hooks';
