'use client';

import React from 'react';
import  StrAuxClient  from './StrAuxComponent';

export default function StrAuxPage() {
  return <StrAuxClient />;
}

