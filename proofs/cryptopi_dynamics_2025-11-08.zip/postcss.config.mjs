// postcss.config.mjs  (Tailwind v3)
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
