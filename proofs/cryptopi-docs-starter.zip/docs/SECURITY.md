# Security

- Use dedicated DB roles: `cp_admin`, `cp_writer`, `cp_reader`.
- RLS: UI and readonly APIs use `cp_reader` only.
- Secrets: never commit API keys. Use `.env.local` and system key vaults.
- Releases are **signed** (see `RELEASE.md`). Docs include signed **Declaração de Veracidade**.
