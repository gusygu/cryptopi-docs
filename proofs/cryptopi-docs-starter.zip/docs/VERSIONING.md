# Versioning

We use **Semantic Versioning**: `MAJOR.MINOR.PATCH` (e.g., `0.1.0`).

- Main repo tag example: `v0.1.0`
- Docs repo tag mirrors main (`v0.1.0`), ensuring a 1:1 mapping.
- Each docs release writes `VERSION` and `SOURCE_TAG`.

Files in this repo:
- `VERSION` — current docs version string.
- `SOURCE_TAG` — the main repo tag this docs set refers to.
