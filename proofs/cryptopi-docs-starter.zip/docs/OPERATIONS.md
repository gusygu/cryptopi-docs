# Operations

## Environments
- Local dev (Node 22+, PNPM)
- PostgreSQL 14–18

## Commands (examples)
```ps1
pnpm run run-ddl
pnpm db:discover
pnpm db:activate
pnpm db:ws
pnpm db:backfill:1d
pnpm smoke:binance
pnpm smoke:pipeline
pnpm smoke:orch
```
Troubleshoot DDL: prefer idempotent drops before signature changes.
