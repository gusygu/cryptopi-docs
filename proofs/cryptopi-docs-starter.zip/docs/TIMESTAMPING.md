# Public Timestamping

Goal: produce an **immutable proof-of-existence** for each release.

**Minimal path**
- Create a **signed git tag** in both repos.
- Export the tag object and store its SHA256 in `DECLARACAO_DE_VERACIDADE.md`.

**Optional hardening**
- Anchor the tag SHA256 into a **public timestamping** service (e.g., Bitcoin-based proofs).
- Store the resulting receipt/artifact in `docs/timestamps/` and add reference here.
