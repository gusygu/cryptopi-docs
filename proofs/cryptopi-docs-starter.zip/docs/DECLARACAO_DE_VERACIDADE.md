# Declaração de Veracidade

Eu, abaixo-assinado, declaro que os documentos nesta versão correspondem fielmente
ao estado do projeto no repositório principal na tag `SOURCE_TAG`.

- **Versão dos documentos**: conteúdo de `VERSION`
- **Tag do repositório principal**: conteúdo de `SOURCE_TAG`
- **Hashes incluídos**:
  - SHA256(ARCHITECTURE.md)=
  - SHA256(DATABASE.md)=
  - SHA256(DDL_ORDER.md)=
  - SHA256(SMOKES.md)=
  - SHA256(OPERATIONS.md)=
  - SHA256(SECURITY.md)=
  - SHA256(VERSIONING.md)=
  - SHA256(RELEASE.md)=
  - SHA256(TIMESTAMPING.md)=

**Assinatura**  
Assinar este arquivo com a sua chave GPG:
```sh
gpg --clearsign docs/DECLARACAO_DE_VERACIDADE.md
```
O arquivo resultante (`.asc`) deve ser versionado junto nesta release.
