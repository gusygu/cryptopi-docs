# DDL Order & Conventions

Suggested file order (example):
```
00_schemas.sql
01_extensions.sql
02_settings.sql
03_market.sql
04_documents.sql
05_wallet.sql
06_str-aux.sql
07_cin-aux-core.sql
08_mea-dynamics.sql
09_ops.sql
10_ingest.sql
11_matrices.sql
...
```
**Rules**
- Never change return type of an existing function without a `DROP ... CASCADE` guarded by `IF EXISTS` + careful dependency notes.
- Use **idempotent** DDL (CREATE IF NOT EXISTS; ALTER guarded; DO $$ ... $$ blocks).
- Keep **generated columns** and **indexes** near their tables.
- Name triggers `trg_<table>__<purpose>` and functions `sp_|fn_|ensure_` prefixes.
