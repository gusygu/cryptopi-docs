# Smokes & Doctor Scripts

Quick harnesses to validate ingestion ↔ DB alignment.

## Current set (examples)
- `smokes/binance-smoke.mts` — ping base URL, coins, klines, orderbook mid.
- `smokes/pipeline-db-smoke.mts` — verify imports, pipeline paths.
- `smokes/str-aux-db-smoke.mts` — check coin universe, windows, required columns.
- `smokes/str-aux-ingest-smoke.mts` — runs `str_aux.recompute_window_stats(...)` sanity.
- `smokes/doctor/str-aux-db-doctor.mts` — comprehensive checks for upserts & schema drift.

### Minimal Acceptance
- **Coin universe** non-empty and mirrored to `market.symbols`.
- **Windows** exist: `1m,3m,5m,15m,1h` (or profile-defined subsets).
- **Str-aux** recompute function exists and returns rows for enabled pairs.
- **Matrices** views present: `v_latest_points`, `v_series_symbol`.
