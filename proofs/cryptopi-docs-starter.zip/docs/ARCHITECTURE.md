# Architecture

CryptoPi is a modular trading & analytics system:
- **settings** — runtime configuration, coin universe, profiles, windows, params.
- **market** — exchange discovery, symbols, klines, orderbook bids/asks.
- **matrices** — id_pct, benchmarks, rollups.
- **str_aux** — structural vectors & stats over windowed market signals.
- **cin_aux** — ledgering & PnL imprint calculations.
- **mea_aux** — mood/dynamics signals feeding matrices.
- **ops/ingest** — daemons, jobs, activation hooks.

### Data flow (high level)
1. **discover** eligible markets → `market.*`
2. **activate** coin universe → mirror to `market.symbols`
3. **ingest** klines/orderbooks → `market.*` raw
4. **str_aux** window recompute → vectors/stats
5. **matrices** rollups → feature tables / views
6. **cin_aux** applies to positions
7. **ui/api** read-only via RLS roles

See `DATABASE.md` for schemas and relations.
