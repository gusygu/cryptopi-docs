# Release Process

1. **Freeze** main repo at a release candidate (RC) commit.
2. Run smokes/doctor; fix drift.
3. Tag main repo: `git tag -s vX.Y.Z -m "Release vX.Y.Z"`
4. Update docs:
   - `VERSION` → `X.Y.Z`
   - `SOURCE_TAG` → `vX.Y.Z`
   - Update `DECLARACAO_DE_VERACIDADE.md` hash list.
5. Tag docs repo the same: `git tag -s vX.Y.Z -m "Docs vX.Y.Z"`
6. **Timestamp** both tags (see `TIMESTAMPING.md`).
7. Publish releases.
