# Contributing

- Propose changes via PRs.
- Keep docs in sync with the main repo state referenced by `SOURCE_TAG`.
- For database changes, update `DDL_ORDER.md` and `DATABASE.md` together.
- Add or update smoke steps in `SMOKES.md` with any new invariants.
