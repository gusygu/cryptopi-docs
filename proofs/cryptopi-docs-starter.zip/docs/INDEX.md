# Index

- [Architecture](ARCHITECTURE.md)
- [Database](DATABASE.md)
- [DDL Order & Conventions](DDL_ORDER.md)
- [Smokes & Doctor Scripts](SMOKES.md)
- [Operations](OPERATIONS.md)
- [Security](SECURITY.md)
- [Versioning](VERSIONING.md)
- [Release Process](RELEASE.md)
- [Public Timestamping](TIMESTAMPING.md)
- [Declaração de Veracidade](DECLARACAO_DE_VERACIDADE.md)
- [Contributing](CONTRIBUTING.md)
- [Code of Conduct](CODE_OF_CONDUCT.md)
