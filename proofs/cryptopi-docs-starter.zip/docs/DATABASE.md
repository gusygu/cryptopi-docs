# Database

**PostgreSQL** with the following schemas:
- `settings` — `profiles`, `windows`, `params`, `coin_universe` (+ hooks).
- `market` — `exchanges`, `coins`, `symbols`, `klines`, `orderbook_*`.
- `matrices` — `benchmarks`, `id_pct`, views like `v_latest_points`/`v_series_symbol`.
- `str_aux` — `vectors`, `stats`, recompute functions.
- `cin_aux` — core tables for PnL imprint.
- `ops` — utilities, upsert helpers.
- `ingest` — job state, cursors, checkpoints.

### Roles & Policies
- `cp_admin`, `cp_writer`, `cp_reader` with RLS defaults to read-only for UI.

See `DDL_ORDER.md` for migration ordering.
