# Code of Conduct

Be respectful. Assume good faith. Focus on technical accuracy and clarity.
