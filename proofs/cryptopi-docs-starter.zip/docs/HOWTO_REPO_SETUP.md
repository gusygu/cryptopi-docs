# How to set up this docs repo

## Create the Git repo (without gh cli)
```sh
git init
git add .
git commit -m "docs: bootstrap"
git branch -M main
git remote add origin https://github.com/<your-username>/cryptopi-docs.git
git push -u origin main
```

## Tag a release (signed recommended)
```sh
git tag -s v0.1.0 -m "Docs v0.1.0"
git push origin v0.1.0
```

## Add as submodule in the main repo
From the main repo root:
```sh
git submodule add https://github.com/<your-username>/cryptopi-docs.git docs
git commit -m "chore: add docs submodule"
```

## Sync to a new version
```ps1
# In docs repo
./scripts/sync-version.ps1 -MainRepoTag v0.1.1
./scripts/hash-docs.ps1
git add VERSION SOURCE_TAG docs/HASHES.sha256.txt docs/DECLARACAO_DE_VERACIDADE.md
git commit -m "docs: sync to v0.1.1"
git tag -s v0.1.1 -m "Docs v0.1.1"
git push --follow-tags
```
