$files = @(
  "docs/ARCHITECTURE.md",
  "docs/DATABASE.md",
  "docs/DDL_ORDER.md",
  "docs/SMOKES.md",
  "docs/OPERATIONS.md",
  "docs/SECURITY.md",
  "docs/VERSIONING.md",
  "docs/RELEASE.md",
  "docs/TIMESTAMPING.md"
)

Write-Host "Computing SHA256 hashes..."
$hashes = foreach($f in $files) {
  $h = (Get-FileHash -Path $f -Algorithm SHA256).Hash.ToLower()
  "$h $f"
}
$hashes | Out-File -Encoding utf8 "docs/HASHES.sha256.txt"
Write-Host "Wrote docs/HASHES.sha256.txt"
