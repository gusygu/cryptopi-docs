param(
  [Parameter(Mandatory=$true)] [string]$MainRepoTag
)

# Write files
Set-Content -Path "$PSScriptRoot\..\VERSION" -Value ($MainRepoTag.TrimStart("v"))
Set-Content -Path "$PSScriptRoot\..\SOURCE_TAG" -Value $MainRepoTag

Write-Host "Updated VERSION and SOURCE_TAG to $MainRepoTag"
