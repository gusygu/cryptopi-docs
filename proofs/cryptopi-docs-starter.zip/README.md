# CryptoPi — Docs Repository

This repository contains **public documentation** for the CryptoPi / CryptoPill project.
It is designed to stay tightly aligned with the current version of the codebase.

## How this repo is used

- **Standalone** documentation hub (`cryptopi-docs`).
- Added as a **git submodule** inside the main code repository at `docs/`.
- Versioned via **git tags** that mirror the main repo's release tags.
- Each release includes an immutable **public timestamp** and a signed **Declaração de Veracidade**.

> Quick links: see `docs/VERSIONING.md`, `docs/RELEASE.md`, `docs/TIMESTAMPING.md`.
