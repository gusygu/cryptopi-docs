export type PreviewSource = "local" | "exchangeInfo" | "ticker" | "empty" | "error";

interface PreviewResponse {
  symbols?: unknown;
  source?: PreviewSource;
}

export async function getPreviewSymbols(
  coins: string[]
): Promise<{ symbols: string[]; source: PreviewSource }> {
  try {
    const response = await fetch("/api/market/preview/symbols", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ coins: coins.map((s) => String(s).toUpperCase()) }),
      cache: "no-store",
    });

    if (!response.ok) return { symbols: [], source: "error" };

    const payload = (await response.json()) as PreviewResponse;
    const rawSymbols = Array.isArray(payload.symbols) ? payload.symbols : [];
    const symbols = rawSymbols
      .map((value) => (typeof value === "string" ? value : String(value ?? "")))
      .filter(Boolean)
      .map((value) => value.toUpperCase());

    return {
      symbols,
      source: payload.source ?? "empty",
    };
  } catch {
    return { symbols: [], source: "error" };
  }
}
