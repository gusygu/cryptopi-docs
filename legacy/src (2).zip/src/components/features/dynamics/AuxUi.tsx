"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useSettings } from "@/lib/settings/provider";
import { useCoinsUniverse, useMeaGrid, usePreviewSymbols, useStrAux } from "@/lib/dynamicsClient";
import type { Coins, Grid } from "@/lib/dynamics.contracts";
import { DynamicsCard } from "./DynamicsCard";
import { classNames, formatNumber, formatPercent, uniqueUpper } from "./utils";

type Props = {
  coins?: Coins;
  base?: string;
  quote?: string;
  onSelectPair?: (base: string, quote: string) => void;
  k?: number;
  className?: string;
};

export default function AuxUi({ coins: coinsProp, base, quote, onSelectPair, className }: Props) {
  const { settings } = useSettings() as any;
  const universe = useCoinsUniverse();

  const clusters = (settings?.clustering?.clusters ?? [
    { id: "cl-1", name: "Cluster 1", coins: [] },
  ]) as Array<{ id: string; name: string; coins: string[] }>;

  const [applyClustering] = useState<boolean>(true);
  const [clusterIdx, setClusterIdx] = useState<number>(0);

  const coinsForAux: Coins = useMemo(() => {
    const envCoins = (coinsProp && coinsProp.length ? coinsProp : universe).map((c) => c.toUpperCase());
    const clusterCoins = (clusters?.[clusterIdx]?.coins ?? []).map((c) => c.toUpperCase());
    const filtered = applyClustering && clusterCoins.length >= 2 ? clusterCoins.filter((c) => envCoins.includes(c)) : envCoins;
    return uniqueUpper(filtered);
  }, [coinsProp?.join("|"), universe.join("|"), applyClustering, clusterIdx, JSON.stringify(clusters)]);

  useEffect(() => {
    if (clusterIdx >= clusters.length) setClusterIdx(0);
  }, [clusterIdx, clusters.length]);

  const [selected, setSelected] = useState<{ base: string; quote: string }>(() => {
    const b = (base || coinsForAux[0] || "BTC").toUpperCase();
    const q = (quote || coinsForAux.find((c) => c !== b) || "USDT").toUpperCase();
    return { base: b, quote: q };
  });

  useEffect(() => {
    const b = (base || selected.base || coinsForAux[0] || "BTC").toUpperCase();
    let q = (quote || selected.quote || coinsForAux.find((c) => c !== b) || "USDT").toUpperCase();
    if (b === q) {
      const alt = coinsForAux.find((c) => c !== b);
      if (alt) q = alt;
    }
    setSelected((prev) => (prev.base === b && prev.quote === q ? prev : { base: b, quote: q }));
  }, [base, quote, coinsForAux.join("|")]);

  const setPair = (b: string, q: string) => {
    const B = b.toUpperCase();
    const Q = q.toUpperCase();
    if (B === Q) return;
    setSelected({ base: B, quote: Q });
    onSelectPair?.(B, Q);
  };

  const { grid: raw, loading: meaLoading, error: meaError, refresh: refreshMea } = useMeaGrid(coinsForAux);
  const grid: Grid | undefined = useMemo(() => {
    if (!raw) return undefined;
    if (Array.isArray(raw)) return raw as Grid;
    if ((raw as any)?.weights) return (raw as any).weights as Grid;
    return undefined;
  }, [raw]);

  const pairStr = `${selected.base}${selected.quote}`.toUpperCase();
  const { mini, loading: strLoading, error: strError, refresh: refreshStr } = useStrAux(pairStr);

  const { symbols: previewSyms } = usePreviewSymbols();
  const previewSet = useMemo(() => new Set(previewSyms.map((x) => String(x).toUpperCase())), [previewSyms]);
  const previewOK = previewSet.has(pairStr);

  const statusText = meaLoading || strLoading ? "Loading..." : meaError || strError ? `Error: ${meaError || strError}` : undefined;

  return (
    <DynamicsCard title="Auxiliaries" subtitle={`${selected.base} / ${selected.quote}`} status={statusText} className={className}>
      <div className="flex h-full flex-col gap-4">
        <section className="grid gap-2 md:grid-cols-3">
          <label className="grid gap-1 text-xs text-slate-300">
            <span>Cluster</span>
            <select
              className="rounded-md border cp-border bg-[#0f141a] px-2 py-1 text-sm"
              value={String(clusterIdx)}
              onChange={(e) => setClusterIdx(Number(e.target.value) || 0)}
            >
              {clusters.map((c, i) => (
                <option key={c.id || i} value={i}>
                  {c.name} ({c.coins.length})
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1 text-xs text-slate-300">
            <span>Base</span>
            <select
              className="rounded-md border cp-border bg-[#0f141a] px-2 py-1 text-sm"
              value={selected.base}
              onChange={(e) => setPair(e.target.value, selected.quote)}
            >
              {coinsForAux.map((c) => (
                <option key={`b-${c}`} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1 text-xs text-slate-300">
            <span>Quote</span>
            <select
              className="rounded-md border cp-border bg-[#0f141a] px-2 py-1 text-sm"
              value={selected.quote}
              onChange={(e) => setPair(selected.base, e.target.value)}
            >
              {coinsForAux
                .filter((c) => c !== selected.base)
                .map((c) => (
                  <option key={`q-${c}`} value={c}>
                    {c}
                  </option>
                ))}
            </select>
          </label>
        </section>

        <section className="rounded-lg border cp-border p-3">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-slate-300">
            <span>MEA snapshot</span>
            <button onClick={refreshMea} className="btn btn-silver btn-xs" type="button">
              Refresh
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {coinsForAux.slice(0, 18).map((c) => {
              const avail = previewSet.has(`${selected.base}${c}`) || previewSet.has(`${c}${selected.base}`);
              return (
                <span
                  key={`k-${c}`}
                  className={classNames(
                    "rounded-md border px-2 py-[3px] text-[11px] font-mono",
                    avail
                      ? "border-emerald-500/40 bg-emerald-600/10 text-emerald-200"
                      : "border-zinc-600/40 bg-black/20 text-zinc-300"
                  )}
                  title={`preview: ${avail ? "available" : "unavailable"}`}
                >
                  {c}
                </span>
              );
            })}
            {!coinsForAux.length && <span className="text-xs text-slate-400">No coins configured.</span>}
          </div>
        </section>

        <section className="rounded-lg border cp-border p-3">
          <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-slate-300">
            <span>STR mini - {selected.base}/{selected.quote}</span>
            <span
              className={classNames(
                "inline-flex items-center gap-2 rounded-xl border px-2.5 py-1 text-[11px]",
                previewOK
                  ? "border-emerald-700/60 bg-emerald-950/30 text-emerald-200"
                  : "border-rose-700/60 bg-rose-950/30 text-rose-200"
              )}
              title={previewOK ? "Preview market available" : "No direct preview market"}
            >
              {pairStr}
              <span className="opacity-70">{previewOK ? "preview on" : "preview off"}</span>
            </span>
            <button onClick={refreshStr} className="btn btn-silver btn-xs" type="button">
              Refresh
            </button>
          </div>

          <div className="grid gap-2 sm:grid-cols-3">
            <MetricChip label="bench" value={mini?.live?.benchmark ?? mini?.benchmark} precision={4} neutral />
            <MetricChip label="id_pct" value={mini?.live?.id_pct ?? mini?.id_pct} precision={6} goodHigh />
            <MetricChip label="pct24h" value={mini?.live?.pct24h ?? mini?.pct24h} precision={2} suffix="%" goodHigh />
          </div>
        </section>

        {grid ? <MatrixPreview grid={grid} coins={coinsForAux} selected={selected} onSelect={setPair} /> : null}
      </div>
    </DynamicsCard>
  );
}

function MetricChip({
  label,
  value,
  precision,
  suffix,
  goodHigh,
  goodLow,
  neutral,
}: {
  label: string;
  value?: number | null;
  precision: number;
  suffix?: string;
  goodHigh?: boolean;
  goodLow?: boolean;
  neutral?: boolean;
}) {
  const numeric = Number(value);
  const bad = !Number.isFinite(numeric);
  const text = bad
    ? "-"
    : suffix === "%"
    ? formatPercent(numeric, { precision })
    : formatNumber(numeric, { precision, minimumFractionDigits: 0 });

  const pos = "bg-emerald-900/35 text-emerald-200 border-emerald-800/50";
  const neg = "bg-rose-900/45 text-rose-200 border-rose-800/60";
  const neu = "bg-slate-800/50 text-slate-200 border-slate-700/60";

  let cls = neu;
  if (!bad && !neutral) {
    if (goodHigh) cls = numeric >= 0 ? pos : neg;
    if (goodLow) cls = numeric <= 0 ? pos : neg;
  }

  return (
    <div className="rounded-xl border px-3 py-2 shadow-inner">
      <div className="mb-0.5 text-[11px] text-slate-400">{label}</div>
      <div className={classNames("inline-flex min-w-[88px] items-center justify-center rounded-lg border px-2 py-1 font-mono text-[11px] tabular-nums", cls)}>
        {text}
      </div>
    </div>
  );
}

function MatrixPreview({
  grid,
  coins,
  selected,
  onSelect,
}: {
  grid: Grid;
  coins: Coins;
  selected: { base: string; quote: string };
  onSelect?: (base: string, quote: string) => void;
}) {
  const rows = coins.length;
  const cols = coins.length;

  const formatCell = (value: unknown) => (
    Number.isFinite(Number(value)) ? formatNumber(value, { precision: 4 }) : "-"
  );

  const handleSelect = (base: string, quote: string) => {
    if (!onSelect || base === quote) return;
    onSelect(base, quote);
  };

  return (
    <section className="rounded-lg border cp-border p-3">
      <div className="mb-2 text-xs text-slate-300">MEA matrix glimpse</div>
      <div className="overflow-x-auto text-[11px]">
        <table className="min-w-full border-collapse">
          <thead>
            <tr>
              <th className="px-2 py-1"></th>
              {coins.map((coin) => (
                <th key={`h-${coin}`} className="px-2 py-1 text-right font-semibold text-slate-300">
                  {coin}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: rows }).map((_, i) => {
              const base = coins[i];
              return (
                <tr key={`r-${base}`}>
                  <td className="px-2 py-1 text-left font-semibold text-slate-300">{base}</td>
                  {Array.from({ length: cols }).map((__, j) => {
                    const quote = coins[j];
                    const value = grid?.[i]?.[j];
                    const active = base === selected.base && quote === selected.quote;

                    if (base === quote) {
                      return (
                        <td key={`c-${i}-${j}`} className="px-2 py-1 text-right text-slate-500">
                          <div className="rounded-md border border-slate-800/60 bg-slate-900/40 px-2 py-1 text-center">-</div>
                        </td>
                      );
                    }

                    return (
                      <td key={`c-${i}-${j}`} className="px-1 py-1">
                        <button
                          type="button"
                          onClick={() => handleSelect(base, quote)}
                          className={classNames(
                            "w-full rounded-md border px-2 py-1 text-right font-mono tabular-nums transition",
                            active
                              ? "border-emerald-600/60 bg-emerald-950/40 text-emerald-100 ring-1 ring-emerald-500/40"
                              : "border-slate-700/60 bg-slate-900/60 text-slate-200 hover:border-emerald-500/50 hover:text-emerald-100"
                          )}
                          title={`${base}/${quote}`}
                        >
                          {formatCell(value)}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
