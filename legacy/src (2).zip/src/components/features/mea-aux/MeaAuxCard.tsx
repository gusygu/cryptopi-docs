"use client";

import React, { useEffect, useState } from "react";
import { colorForChange } from "@/components/features/matrices/colors";

type Props = {
  coins?: string[];
  defaultK?: number;
  autoRefreshMs?: number; // UI cadence (API side can still coalesce)
  className?: string;
};

type Pair = { base: string; quote: string; id_pct: number | null };

export default function MeaAuxCard({
  coins = ["BTC", "ETH", "BNB", "SOL", "ADA", "XRP", "PEPE", "USDT"],
  defaultK = 7,
  autoRefreshMs = 45_000,
  className = "",
}: Props) {
  const [rows, setRows] = useState<Pair[]>([]);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);

  async function refresh() {
    try {
      // best-effort: try to reuse /api/matrices/latest id_pct
      const r = await fetch(`/api/matrices/latest?t=${Date.now()}`, { cache: "no-store" });
      const j = await r.json();
      const cs: string[] = Array.isArray(j?.coins) ? j.coins : coins;
      const idpct = j?.matrices?.id_pct?.values || {};
      const out: Pair[] = [];

      // pick top |id_pct| pairs vs USDT for a quick display
      const U = cs.map((c) => String(c).toUpperCase());
      const usdt = U.indexOf("USDT");

      for (let i = 0; i < U.length; i++) {
        if (i === usdt) continue;
        const base = U[i];
        const v = Number(idpct?.[base]?.["USDT"]);
        out.push({ base, quote: "USDT", id_pct: Number.isFinite(v) ? v : null });
      }

      out.sort((a, b) => Math.abs(b.id_pct ?? 0) - Math.abs(a.id_pct ?? 0));
      setRows(out.slice(0, Math.max(1, defaultK)));
      setUpdatedAt(Date.now());
    } catch {
      // keep prior state
    }
  }

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, Math.max(15_000, autoRefreshMs));
    return () => clearInterval(id);
  }, [autoRefreshMs, defaultK]);

  return (
    <div className={`w-full ${className}`}>
      <div className="flex items-center justify-between mb-2">
        <h3 className="cp-h3">MEA-AUX</h3>
        <div className="text-[11px] cp-subtle">
          k <span className="cp-pill-silver">{defaultK}</span>{" "}
          <span className="cp-pill-silver">{updatedAt ? new Date(updatedAt).toLocaleTimeString() : "—"}</span>
        </div>
      </div>

      <div className="overflow-auto rounded-md border border-white/5">
        <table className="w-full text-sm num num-tabular">
          <thead className="bg-white/5">
            <tr>
              <th className="p-2 text-left">Base \\ Quote</th>
              <th className="p-2 text-right">id_pct (decimal)</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td className="p-2 text-left cp-subtle" colSpan={2}>
                  No MEA values yet.
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr key={`${r.base}/USDT`} className="border-t border-white/5">
                <td className="p-2 text-left">{r.base}/USDT</td>
                <td className="p-2 text-right">
                  <span
                    className="inline-flex min-w-[96px] justify-end rounded px-2 py-1 font-mono text-[13px] tabular-nums"
                    style={{
                      background: colorForChange(r.id_pct),
                      color: r.id_pct == null ? "#e2e8f0" : r.id_pct < 0 ? "#f8fafc" : "#0f172a",
                      boxShadow: "inset 0 1px 0 rgba(255,255,255,0.35)",
                    }}
                  >
                    {r.id_pct == null ? "-" : r.id_pct.toFixed(6)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

