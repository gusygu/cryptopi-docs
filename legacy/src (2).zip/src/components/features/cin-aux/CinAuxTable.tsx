"use client";

import React, { useEffect, useState } from "react";

type Props = {
  clusterCoins?: string[];
  title?: string;
  /** compact typography toggle */
  dense?: boolean;
  className?: string;
};

export default function CinAuxTable({
  clusterCoins = [],
  title = "CIN-AUX",
  dense = false,
  className = "",
}: Props) {
  const [coins, setCoins] = useState<string[]>(clusterCoins);

  useEffect(() => {
    setCoins(clusterCoins);
  }, [clusterCoins]);

  return (
    <div
      className={[
        "rounded-2xl border border-slate-800 bg-slate-900/60",
        dense ? "text-[12px]" : "text-sm",
        "flex h-full flex-col",
        className,
      ]
        .filter(Boolean)
        .join(" ")}
    >
      {/* header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="text-sm font-semibold text-slate-200">{title}</div>
        <div className="text-[11px] cp-subtle">{coins.length} symbols</div>
      </div>

      {/* table */}
      <div className="overflow-auto">
        <table className="w-full num num-tabular">
          <thead className="bg-white/5">
            <tr>
              <th className="px-3 py-2 text-left">Symbol</th>
              <th className="px-3 py-2 text-right">Wallet (USDT)</th>
              <th className="px-3 py-2 text-right">Profit (USDT) ↓</th>
              <th className="px-3 py-2 text-right">Imprint (session)</th>
              <th className="px-3 py-2 text-right">Luggage (session)</th>
              <th className="px-3 py-2 text-right">Imprint (cycle)</th>
              <th className="px-3 py-2 text-right">Luggage (cycle)</th>
            </tr>
          </thead>
          <tbody>
            {coins.length === 0 && (
              <tr>
                <td className="px-3 py-4 text-center cp-subtle" colSpan={7}>
                  No data yet.
                </td>
              </tr>
            )}
            {coins.map((sym) => (
              <tr key={sym} className="border-t border-white/5">
                <td className="px-3 py-2">{sym}</td>
                <td className="px-3 py-2 text-right">0.00</td>
                <td className="px-3 py-2 text-right">0.00</td>
                <td className="px-3 py-2 text-right">0.00</td>
                <td className="px-3 py-2 text-right">0.00</td>
                <td className="px-3 py-2 text-right">0.00</td>
                <td className="px-3 py-2 text-right">0.00</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
