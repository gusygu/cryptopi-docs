// src/core/pipelines/pipeline.ts
// Orchestrates pipelines, driven by the universal poller.

import type { OrchestratorCtx, PipelineSettings, PollTick, MatrixType, LiveSnapshot, PriceBook } from "./types";
import { upsertMatrixGrid, getPrevMatrixValue } from "./pipeline.db";
import { buildPrimaryDirect as mathBuildPrimaryDirect, buildDerived as mathBuildDerived } from "@/core/maths/math";
import { appendAppLedger } from "@/core/db/ledger";
import { fetchLiveSnapshot } from "@/core/pipeline/source";

type OrchestratorHooks = {
  // A function that subscribes to your universal poller and yields ticks.
  // Example: an AsyncGenerator from /core/poller/metronome.
  subscribe: () => AsyncIterable<PollTick>;
  // Optional hook when a cycle finishes
  onCycleDone?: (tick: PollTick) => void | Promise<void>;
};

export async function runOrchestrator(ctx: OrchestratorCtx, hooks: OrchestratorHooks) {
  const { settings } = ctx;

  for await (const tick of hooks.subscribe()) {
  const cfg = settings.matrices.period;
  const ms = typeof cfg === "number" ? cfg : parsePeriod(cfg);

  // 1) PERIOD CHECK
  if (!periodMatches(cfg, tick.periodMs)) {
    const rem = tick.periodMs % ms;
    ctx.logger?.debug?.("orchestrator:skip", {
      reason: "period-mismatch",
      tickPeriodMs: tick.periodMs,
      cfgPeriod: cfg,
      parsedCfgMs: ms,
      remainder: rem
    });
    continue;
  }

  ctx.logger?.debug?.("orchestrator:tick", {
    cycleTs: tick.cycleTs, periodMs: tick.periodMs, cfgPeriod: cfg
  });

  try {
    // 2) SNAPSHOT FETCH (trace around it)
    const t0 = Date.now();
    const snapshot = await fetchLiveSnapshot(ctx.settings, tick, ctx.logger);
    const dt = Date.now() - t0;

    const pb = snapshot.priceBook ?? { direct: {}, usdt: {}, open24h: {} };
    const obCount = Object.keys(snapshot.orderBooks ?? {}).length;
    const walCount = Object.keys(snapshot.wallet ?? {}).length;

    ctx.logger?.debug?.("snapshot:stats", {
      ms: dt,
      price_direct: Object.keys(pb.direct ?? {}).length,
      price_usdt: Object.keys(pb.usdt ?? {}).length,
      price_open24h: Object.keys(pb.open24h ?? {}).length,
      orderBooks: obCount,
      walletAssets: walCount
    });

    await runMatricesCycle(ctx, tick, snapshot);
    await hooks.onCycleDone?.(tick);
  } catch (e) {
    ctx.logger?.error?.("orchestrator:error", e);
  }
}

/** One matrices cycle: compute → optionally persist */
export type MatricesCycleResult = {
  ts_ms: number;
  bases: string[];
  quote: string;
  snapshot: LiveSnapshot;
  matrices: {
    benchmark: (number | null)[][];
    delta: (number | null)[][];
    pct24h: (number | null)[][];
    id_pct: (number | null)[][];
    pct_drv: (number | null)[][];
  };
  orderBooks: LiveSnapshot["orderBooks"];
  wallet: LiveSnapshot["wallet"];
  persisted?: Record<MatrixType, number>;
};

export async function runMatricesCycle(
  ctx: OrchestratorCtx,
  tick: PollTick,
  snapshot: LiveSnapshot,
): Promise<MatricesCycleResult> {
  const S = ctx.settings.matrices;
  const bases = [...new Set(S.bases.map((s) => s.toUpperCase()))];
  const quote = S.quote.toUpperCase();
  const ts_ms = tick.cycleTs;

  const { priceBook, orderBooks, wallet } = snapshot;

  const { benchmark, delta, pct24h } = mathBuildPrimaryDirect(bases, mapFromBook(priceBook, quote));
  const derived = await mathBuildDerived(
    bases,
    ts_ms,
    benchmark,
    (matrix, base, q, before) => getPrevMatrixValue(matrix, base, q, before)
  );

  let persisted: Record<MatrixType, number> | undefined;
  if (S.persist) {
    persisted = {
      benchmark: await upsertMatrixGrid("benchmark", bases, quote, benchmark, ts_ms),
      pct24h:   await upsertMatrixGrid("pct24h",   bases, quote, pct24h,   ts_ms),
      delta:    await upsertMatrixGrid("delta",    bases, quote, delta,    ts_ms),
      id_pct:   await upsertMatrixGrid("id_pct",   bases, quote, derived.id_pct, ts_ms),
      pct_drv:  await upsertMatrixGrid("pct_drv",  bases, quote, derived.pct_drv, ts_ms),
    } satisfies Record<MatrixType, number>;

    const written = (Object.entries(persisted) as Array<[MatrixType, number]>).map(([matrix, count]) => ({ matrix, count }));

    try {
      await appendAppLedger({
        topic: "pipeline",
        event: "matrices_upsert",
        payload: {
          bases,
          quote,
          ts_ms,
          written,
          orderBooks: Object.keys(orderBooks).length,
          walletAssets: Object.keys(wallet).length,
        },
        session_id: tick.appSessionId ?? undefined,
        ts_epoch_ms: Date.now(),
      });
    } catch {/* non-fatal */}
  }

  return {
    ts_ms,
    bases,
    quote,
    snapshot,
    matrices: {
      benchmark,
      delta,
      pct24h,
      id_pct: derived.id_pct,
    pct_drv: derived.pct_drv,
    },
    orderBooks,
    wallet,
    persisted,
  };
}

/* ------------------------------ helpers ------------------------------ */

function periodMatches(cfg: number | string, tickMs: number): boolean {
  const ms = typeof cfg === "number" ? cfg : parsePeriod(cfg);
  // allow exact match or integer multiples of the base period
  return tickMs % ms === 0;
}

function parsePeriod(s: string): number {
  const re = /(\d+)(ms|s|m|h|d)$/i;
  const m = s.match(re);
  if (!m) return 60_000;
  const v = Number(m[1]); const u = m[2].toLowerCase();
  if (u === "ms") return v;
  if (u === "s")  return v * 1_000;
  if (u === "m")  return v * 60_000;
  if (u === "h")  return v * 3_600_000;
  if (u === "d")  return v * 86_400_000;
  return 60_000;
}

function mapFromBook(book: PriceBook, quote: string) {
  // Provide least needed fields to your math builder:
  const tmap: Record<string, { lastPrice?: string; weightedAvgPrice?: string; priceChangePercent?: string }> = {};
  for (const [pair, price] of Object.entries(book.direct as Record<string, number>)) {
    if (!pair.endsWith(`/${quote}`)) continue;
    tmap[pair.replace("/", "")] = { lastPrice: String(price) };
  }
  for (const [pair, price] of Object.entries(book.usdt as Record<string, number>)) {
    tmap[pair.replace("/", "")] = { lastPrice: String(price) };
  }
  return tmap as any;
}
}