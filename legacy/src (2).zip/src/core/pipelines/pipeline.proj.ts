// src/core/pipelines/proj_pipeline.ts
// Non-persistent computations you can pass between projects.

import type { PipelineSettings, PollTick, MatrixType, LiveSnapshot, PriceBook } from "./types";
import { fetchLiveSnapshot } from "@/core/pipeline/source";
import { buildPrimaryDirect as mathBuildPrimaryDirect, buildDerived as mathBuildDerived } from "@/core/maths/math";

export type TransientMatrices = {
  ts_ms: number;
  quote: string;
  bases: string[];
  matrices: Record<MatrixType, (number | null)[][]>;
};

export async function buildTransientMatrices(
  ctx: { settings: PipelineSettings; tick: PollTick; logger?: Console },
): Promise<TransientMatrices> {
  const { matrices } = ctx.settings;
  const bases = [...new Set(matrices.bases.map((s) => s.toUpperCase()))];
  const quote = matrices.quote.toUpperCase();
  const ts_ms = ctx.tick.cycleTs;

  const snapshot: LiveSnapshot = await fetchLiveSnapshot(ctx.settings, ctx.tick, ctx.logger);
  const priceBook: PriceBook = snapshot.priceBook;

  const { benchmark, delta, pct24h } = mathBuildPrimaryDirect(bases, mapFromBook(priceBook, quote));
  const derived = await mathBuildDerived(
    bases,
    ts_ms,
    benchmark,
    async () => null
  );

  return {
    ts_ms,
    quote,
    bases,
    matrices: {
      benchmark,
      pct24h,
      delta,
      id_pct: derived.id_pct,
      pct_drv: derived.pct_drv,
    },
  };
}

/* Minimal mapper matching your math.buildPrimaryDirect expectation */
function mapFromBook(book: PriceBook, quote: string) {
  const tmap: Record<string, { lastPrice?: string; weightedAvgPrice?: string; priceChangePercent?: string }> = {};
  for (const [pair, price] of Object.entries(book.direct)) {
    if (!pair.endsWith(`/${quote}`)) continue;
    tmap[pair.replace("/", "")] = { lastPrice: String(price) };
  }
  for (const [pair, price] of Object.entries(book.usdt ?? {})) {
    tmap[pair.replace("/", "")] = { lastPrice: String(price) };
  }
  return tmap as any;
}

export type TransientEnvelope<T> = {
  producer: string;
  consumer?: string;
  createdAt: number;
  cycleTs?: number;
  tags?: string[];
  payload: T;
};

export function makeTransient<T>(producer: string, payload: T, meta?: { consumer?: string; cycleTs?: number; tags?: string[] }): TransientEnvelope<T> {
  return {
    producer,
    consumer: meta?.consumer,
    createdAt: Date.now(),
    cycleTs: meta?.cycleTs,
    tags: meta?.tags ?? [],
    payload,
  };
}
