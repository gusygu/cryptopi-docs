// opening.ts — session/day opening (reference) provider for matrices
// Reads from public.dyn_matrix_values (your persisted grid) to build the opening benchmark grid.

import { db } from "@/core/db/db";

export type OpeningArgs = {
  coins: string[];           // uppercase coin universe
  quote?: string;            // default "USDT" (not required for the grid)
  appSessionId?: string | null;
  window?: string;           // e.g., "1h"
  openingTs?: number;        // optional override
};

type Grid = (number | null)[][];
const makeGrid = (n: number) => Array.from({ length: n }, () => Array(n).fill(null as number | null));

// --- optional session opening ts helper ---
async function resolveOpeningTs(
  appSessionId: string | null | undefined,
  window: string
): Promise<number | null> {
  // If you have a helper function for session opening, we try it.
  try {
    const { rows } = await db.query<{ ts_ms: string }>(
      `select ts_ms from get_session_opening_ts($1::text, $2::text) limit 1`,
      [appSessionId ?? null, window]
    );
    if (rows?.[0]?.ts_ms) return Number(rows[0].ts_ms);
  } catch { /* helper may not exist — ignore */ }
  return null;
}

/**
 * Build a dense N×N opening grid for matrix_type='benchmark'.
 * If openingTs provided/available → pick first at-or-after openingTs per pair,
 * else → pick earliest available per pair (safe fallback).
 */
export async function fetchOpeningGridFromView(args: OpeningArgs): Promise<{ ts: number; grid: Grid }> {
  const coins = Array.from(new Set(args.coins.map(c => c.toUpperCase())));
  const n = coins.length;

  let openingTs = args.openingTs ?? null;
  if (!openingTs) {
    openingTs = await resolveOpeningTs(args.appSessionId ?? null, args.window ?? "1h");
  }

  const grid = makeGrid(n);
  let effTs = 0;

  if (openingTs != null) {
    // first row >= openingTs per pair from dyn_matrix_values
    const { rows } = await db.query<{
      base: string; quote: string; value: string; ts_ms: string;
    }>(
      `
      with pairs as (
        select b as base, q as quote
        from unnest($1::text[]) as b
        cross join unnest($2::text[]) as q
      )
      select vm.base, vm.quote, vm.value::text as value, vm.ts_ms::text as ts_ms
        from pairs p
        join lateral (
          select base, quote, value, ts_ms
            from public.dyn_matrix_values
           where matrix_type = 'benchmark'
             and base = p.base and quote = p.quote
             and ts_ms >= $3
        order by ts_ms asc
           limit 1
        ) vm on true
      `,
      [coins, coins, openingTs]
    );

    for (const r of rows) {
      const i = coins.indexOf(r.base.toUpperCase());
      const j = coins.indexOf(r.quote.toUpperCase());
      if (i >= 0 && j >= 0 && i !== j) {
        grid[i][j] = Number(r.value);
        const t = Number(r.ts_ms);
        if (Number.isFinite(t) && t > effTs) effTs = t;
      }
    }
    return { ts: effTs || openingTs, grid };
  }

  // fallback: earliest available per pair
  const { rows } = await db.query<{
    base: string; quote: string; value: string; ts_ms: string;
  }>(
    `
    with pairs as (
      select b as base, q as quote
      from unnest($1::text[]) as b
      cross join unnest($2::text[]) as q
    )
    select vm.base, vm.quote, vm.value::text as value, vm.ts_ms::text as ts_ms
      from pairs p
      join lateral (
        select base, quote, value, ts_ms
          from public.dyn_matrix_values
         where matrix_type = 'benchmark'
           and base = p.base and quote = p.quote
      order by ts_ms asc
         limit 1
      ) vm on true
    `,
    [coins, coins]
  );

  for (const r of rows) {
    const i = coins.indexOf(r.base.toUpperCase());
    const j = coins.indexOf(r.quote.toUpperCase());
    if (i >= 0 && j >= 0 && i !== j) {
      grid[i][j] = Number(r.value);
      const t = Number(r.ts_ms);
      if (Number.isFinite(t) && t > effTs) effTs = t;
    }
  }
  return { ts: effTs, grid };
}

/** Pair-level helper (optional). */
export async function getOpeningPairValue(args: {
  base: string; quote: string; appSessionId?: string | null; window?: string; openingTs?: number;
}): Promise<{ ts: number | null; price: number | null }> {
  const { base, quote } = args;
  const { grid, ts } = await fetchOpeningGridFromView({
    coins: [base.toUpperCase(), quote.toUpperCase()],
    quote: quote.toUpperCase(),
    appSessionId: args.appSessionId ?? null,
    window: args.window ?? "1h",
    openingTs: args.openingTs
  });
  return { ts, price: grid?.[0]?.[1] ?? null };
}
