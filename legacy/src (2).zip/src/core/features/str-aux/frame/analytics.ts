// src/str-aux/frame/analytics.ts
// STR-AUX frame-level analytics: apply GFM shift logic + streams stamping
// Rule: if |ΔGFM %| > epsilonPct for 5 consecutive cycles ⇒ mark shift & update streams.
//
// This module is intentionally small and framework-free so it can be reused
// from API routes or jobs. No DB access here — just pure session/state mutation.

export type ShiftWindowState = {
  // rolling window of boolean flags for "delta exceeded epsilonPct" per cycle
  exceed: boolean[];
  // last computed delta in percent points
  lastDeltaPct?: number;
  // total shifts detected (lifetime, maintained by caller if persisted)
  shifts?: number;
};

export type StreamsState = {
  // minimal sketch — caller can extend
  lastShiftTs?: number;
  lastShiftPrice?: number;
  lastShiftGfm?: number;
  // recent stamps (fixed size for UI)
  stamps?: Array<{ ts: number; price: number; gfm: number; deltaPct: number }>;
  maxStamps?: number; // default 64
};

export type ApplyGfmShiftOpts = {
  epsilonPct?: number; // threshold in percentage points (default 0.35%)
  windowSize?: number; // consecutive cycles needed (default 5)
  nowTs?: number;      // override clock if needed
  price?: number;      // last price at this cycle (for stamping)
};

/**
 * Update shift window & streams given current GFM vs reference.
 * Returns flags telling the caller whether this cycle stamped a new shift.
 */
export function applyGfmShiftAndStreams(
  gfm: number,          // current GFM in [0..1]
  refGfm: number,       // reference GFM in [0..1]
  state: ShiftWindowState,
  streams: StreamsState,
  opts: ApplyGfmShiftOpts = {}
): { isShift: boolean; deltaPct: number; window: ShiftWindowState; streams: StreamsState } {
  const epsilonPct = opts.epsilonPct ?? 0.35; // %
  const windowSize = Math.max(1, Math.floor(opts.windowSize ?? 5));
  const now = opts.nowTs ?? Date.now();

  // convert delta to percent of full scale (0..1 ⇒ 0..100%)
  const deltaPct = 100 * (gfm - refGfm);

  // slide window
  const exceeded = Math.abs(deltaPct) > epsilonPct;
  const nextExceed = (state.exceed ?? []).slice(-windowSize + 1).concat([exceeded]);

  // condition: all last `windowSize` cycles exceeded threshold
  const allExceed = nextExceed.length >= windowSize && nextExceed.every(Boolean);

  let isShift = false;
  const outStreams: StreamsState = { ...streams };
  const outState: ShiftWindowState = {
    exceed: nextExceed,
    lastDeltaPct: deltaPct,
    shifts: state.shifts ?? 0,
  };

  if (allExceed) {
    isShift = true;
    outState.shifts = (outState.shifts ?? 0) + 1;

    const stamp = {
      ts: now,
      price: Number.isFinite(opts.price as number) ? (opts.price as number) : NaN,
      gfm,
      deltaPct,
    };

    const maxStamps = outStreams.maxStamps ?? 64;
    const stamps = (outStreams.stamps ?? []).slice(-(maxStamps - 1)).concat([stamp]);

    outStreams.lastShiftTs = now;
    outStreams.lastShiftPrice = stamp.price;
    outStreams.lastShiftGfm = gfm;
    outStreams.stamps = stamps;
    outStreams.maxStamps = maxStamps;
  }

  return { isShift, deltaPct, window: outState, streams: outStreams };
}
