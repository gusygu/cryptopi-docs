// src/core/features/str-aux/calc/executive.ts
import type { SnapshotWithRefs } from "../frame";
import { computeFM } from "@/core/features/str-aux/frame/idhr";                 // IDHR + gfm  :contentReference[oaicite:11]{index=11}
import * as Tend from "@/core/features/str-aux/calc/tendency";       // vectors     :contentReference[oaicite:12]{index=12}
import * as Met from "@/core/features/str-aux/calc/metrics";                    // inertia…    :contentReference[oaicite:13]{index=13}
import {
  getOrInitSymbolSession,
  updateSymbolSession,
  type Snapshot as SessSnap
} from "@/core/features/str-aux/frame/session";                                           // session API :contentReference[oaicite:14]{index=14}

export type MarketPoint = { ts: number; price: number };
export type OpeningExact = { benchmark: number | null };

function toSeries(payload: SnapshotWithRefs): Record<string, MarketPoint[]> {
  const ts = payload.snapshot.tick.cycleTs ?? payload.frames.cycleStart;
  const out: Record<string, MarketPoint[]> = {};
  for (const p of payload.snapshot.points) {
    const price = Number(p.mid ?? NaN);
    if (!Number.isFinite(price)) continue;
    (out[p.symbol] ??= []).push({ ts, price });
  }
  return out;
}

function openingFromSeries(series: MarketPoint[]): OpeningExact {
  const first = series.find(p => Number.isFinite(p.price));
  return { benchmark: first ? first.price : null };
}

export type ExecResult = {
  pair: string;
  idhr: { gfm: number | null; sigmaGlobal: number | null; zMeanAbs: number | null; nuclei: any[] };
  vectors: { vInner?: number; vOuter?: number; vTendency?: number };
  metrics: { inertia?: { static: number; growth: number; total: number } | null };
  session: {
    uiEpoch: number; gfmRefPrice: number | null; gfmCalcPrice: number | null; gfmDeltaAbsPct: number;
    snapshot: SessSnap;
  };
};

export function executeCalcAndUpdateSession(
  appSessionId: string,
  payload: SnapshotWithRefs,
  seriesBuffers: Record<string, MarketPoint[]>,  // ring-buffers per "BASE/QUOTE"
  pct24hMap?: Record<string, number>,           // optional 24h %
): ExecResult[] {
  const res: ExecResult[] = [];
  const seriesNow = toSeries(payload);

  for (const [pair, pts] of Object.entries(seriesNow)) {
    // append into buffers
    const buf = seriesBuffers[pair] = (seriesBuffers[pair] ?? []).concat(pts).slice(-3600);

    const opening = openingFromSeries(buf);
    const idhr = computeFM(buf as any, opening as any); // returns { gfm, sigmaGlobal, zMeanAbs, nuclei }  :contentReference[oaicite:15]{index=15}
    const gfmCalcPrice = Number.isFinite(idhr?.gfm) ? idhr.gfm : NaN;

    // simple tendency from last N returns (use z as unitless)
    const returns = buf.slice(-60).map((p, i, a) => i ? (100 * (p.price / a[i-1].price - 1)) : 0).slice(1);
    const vin = returns.length ? Tend.vInner({ values: returns }, { scale: 100 }) : 0;
const vout = returns.length ? Tend.vOuter([{ values: returns }], undefined, { scale: 100 }) : 0;
const vt   = returns.length ? Tend.vTendencyFromSeries(returns, { scale: 100 }).score : 0;

    // inertia example: from returns only (window=returns.length)
    const inertia = returns.length
      ? Met.inertiaFromReturns(returns, { window: returns.length })
      : null;

    // session update
    const nowTs = payload.frames.cycleEnd ?? payload.snapshot.tick.cycleTs ?? Date.now();
    const priceNow = buf[buf.length - 1]?.price ?? NaN;
    const pct24hNow = Number(pct24hMap?.[pair] ?? 0);

    const ss = getOrInitSymbolSession(appSessionId, pair, opening.benchmark ?? priceNow ?? 0, nowTs);
    const upd = updateSymbolSession(ss, priceNow, nowTs, gfmCalcPrice, pct24hNow);                     // :contentReference[oaicite:17]{index=17}

   res.push({
      pair,
      idhr: {
        gfm: Number.isFinite(idhr.gfm) ? idhr.gfm : null,
        sigmaGlobal: Number.isFinite(idhr.sigmaGlobal) ? idhr.sigmaGlobal : null,
        zMeanAbs: Number.isFinite(idhr.zMeanAbs) ? idhr.zMeanAbs : null,
        nuclei: idhr.nuclei ?? [],
      },
      vectors: { vInner: vin, vOuter: vout, vTendency: vt },
      metrics: { inertia },
      session: {
        uiEpoch: upd.uiEpoch,
        gfmRefPrice: upd.gfmRefPrice,
        gfmCalcPrice: upd.gfmCalcPrice,
        gfmDeltaAbsPct: upd.gfmDeltaAbsPct,
        // snapshot (optional, if you need it downstream)
        // snapshot: ss.snapCur,
      },
    });
  }

  return res;
}
