// src/core/features/mea-aux/grid.ts
import type { TierRule } from "./tiers";
import { DEFAULT_TIER_RULES, getTierWeighting } from "./tiers";

export type IdPctGrid = Record<string, Record<string, number | null>>;
export type BalancesMap = Record<string, number>;
export type MeaAuxGrid = Record<string, Record<string, number | null>>;
export type MeaPair = { base: string; quote: string; value: number; frozen?: boolean };

export function buildMeaAux(params: {
  coins: string[];
  idPct: IdPctGrid;
  balances: BalancesMap;
  k?: number;
  rules?: TierRule[];
  coverage?: Record<string, Record<string, boolean>>;
}): MeaAuxGrid {
  const { coins, idPct, balances, coverage, rules = DEFAULT_TIER_RULES } = params;
  const k = Math.max(1, params.k ?? coins.length - 1);

  const out: MeaAuxGrid = {};
  for (const base of coins) {
    const avail = balances[base] ?? 0;
    const row: Record<string, number | null> = {};
    for (const quote of coins) {
      if (quote === base) {
        row[quote] = null;
        continue;
      }
      if (coverage && coverage[base] && coverage[base][quote] === false) {
        row[quote] = null;
        continue;
      }
      const idp = idPct?.[base]?.[quote];
      const w = getTierWeighting(Number(idp ?? 0), rules);
      row[quote] = avail * (1 / k) * w;
    }
    out[base] = row;
  }
  return out;
}

export async function buildMeaAuxForCycle(params: {
  appSessionId: string;
  cycleTs: number;
  coins: string[];
  idPct: IdPctGrid;
  balances: BalancesMap;
  k?: number;
  rules?: TierRule[];
  coverage?: Record<string, Record<string, boolean>>;
  getFrozenSet?: (appSessionId: string, cycleTs: number) => Promise<Set<string>>;
}): Promise<{ coins: string[]; grid: MeaAuxGrid; pairs: MeaPair[] }> {
  const { appSessionId, cycleTs, coins, getFrozenSet } = params;
  const grid = buildMeaAux(params);

  const frozenSet = getFrozenSet ? await getFrozenSet(appSessionId, cycleTs) : new Set<string>();
  const pairs: MeaPair[] = [];
  for (const base of coins) {
    for (const quote of coins) {
      if (quote === base) continue;
      const key = `${base.toUpperCase()}|${quote.toUpperCase()}`;
      const frozen = frozenSet.has(key);
      const v = Number(grid[base]?.[quote] ?? 0);
      const value = frozen ? 0 : Number.isFinite(v) ? v : 0;
      pairs.push({ base, quote, value, frozen });
      if (frozen) grid[base][quote] = 0;
    }
  }
  return { coins, grid, pairs };
}

export type MeaRow = {
  key: string;
  value: number | string | null;
  label?: string;
};

export function toRenderableRows(mea: Record<string, Record<string, {
  id_pct: number;
  weight: number;
  tierName?: string;
  isNull?: boolean;
}>>): Array<{
  base: string;
  quote: string;
  id_pct_display: string;
  weight_display: string;
  tierName?: string;
  isNull: boolean;
}> {
  const rows: Array<{
    base: string;
    quote: string;
    id_pct_display: string;
    weight_display: string;
    tierName?: string;
    isNull: boolean;
  }> = [];

  for (const base of Object.keys(mea)) {
    for (const quote of Object.keys(mea[base])) {
      const cell = mea[base][quote];
      rows.push({
        base,
        quote,
        id_pct_display: Number(cell.id_pct ?? 0).toFixed(6),
        weight_display: Number.isFinite(cell.weight) ? cell.weight.toFixed(4) : "-",
        tierName: cell.tierName,
        isNull: !!cell.isNull,
      });
    }
  }
  return rows;
}

