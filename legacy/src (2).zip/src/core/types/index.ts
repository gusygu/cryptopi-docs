export type Scale = number;
