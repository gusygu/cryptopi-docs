// src/core/db/ledger.ts
import { db } from "./db";

export type AppLedgerEvent = {
  topic: string;           // "calc" | "api" | "pipeline" | "cin-aux" | ...
  event: string;           // e.g. "dyn_matrix_upsert"
  payload?: unknown;
  session_id?: string;
  idempotency_key?: string;
  ts_epoch_ms: number;
};

/** Lightweight application ledger (generic events) */
export async function appendAppLedger(e: AppLedgerEvent) {
  await db.query(
    `INSERT INTO app_ledger (topic, event, payload, session_id, idempotency_key, ts_epoch_ms)
     VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (idempotency_key) DO NOTHING`,
    [e.topic, e.event, e.payload ?? null, e.session_id ?? null, e.idempotency_key ?? null, e.ts_epoch_ms]
  );
}

export async function getAppLedgerSince(sinceMs: number, topic?: string) {
  const { rows } = await db.query(
    `SELECT * FROM app_ledger
      WHERE ts_epoch_ms >= $1
        AND ($2::text IS NULL OR topic = $2)
  ORDER BY ts_epoch_ms ASC`,
    [sinceMs, topic ?? null]
  );
  return rows;
}

/** Route-level transfer ledger (execution journal) */
export async function appendTransferLedger(row: {
  app_session_id: string; cycle_ts: number; leg_seq: number;
  route_id?: string | null; intent_id?: string | null;
  from_symbol: string; to_symbol: string;
  qty_from: number; qty_to: number;
  price_from_usdt: number; price_to_usdt: number;
  fee_usdt?: number; exec_ts: number; tx_id?: string | null;
}) {
  const q = `
    INSERT INTO transfer_ledger (
      app_session_id, cycle_ts, leg_seq, route_id, intent_id,
      from_symbol, to_symbol, qty_from, qty_to,
      price_from_usdt, price_to_usdt, fee_usdt, exec_ts, tx_id
    ) VALUES (
      $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,COALESCE($12,0),$13,$14
    ) ON CONFLICT (app_session_id, cycle_ts, leg_seq) DO NOTHING
  `;
  await db.query(q, [
    row.app_session_id, row.cycle_ts, row.leg_seq, row.route_id ?? null, row.intent_id ?? null,
    row.from_symbol, row.to_symbol, row.qty_from, row.qty_to,
    row.price_from_usdt, row.price_to_usdt, row.fee_usdt ?? 0, row.exec_ts, row.tx_id ?? null
  ]);
}

/** CIN/AUX-friendly views & queries */
export async function getTransferRollup(app_session_id: string, sinceTs?: number) {
  const { rows } = await db.query(
    `SELECT * FROM v_transfer_ledger_rollup
      WHERE app_session_id = $1
        AND ($2::bigint IS NULL OR cycle_ts >= $2)
  ORDER BY cycle_ts ASC`,
    [app_session_id, sinceTs ?? null]
  );
  return rows;
}

export async function listTransferLegs(app_session_id: string, opts?: { before?: number; limit?: number }) {
  const { rows } = await db.query(
    `SELECT * FROM transfer_ledger
      WHERE app_session_id = $1
        AND ($2::bigint IS NULL OR cycle_ts < $2)
  ORDER BY cycle_ts DESC, leg_seq DESC
     LIMIT $3`,
    [app_session_id, opts?.before ?? null, opts?.limit ?? 200]
  );
  return rows;
}
