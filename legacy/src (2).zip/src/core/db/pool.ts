// src/core/db/pool.ts
import { Pool, type PoolClient } from "pg";

/**
 * Centralized PG pool with timing from environment "settings".
 * Env knobs (all optional):
 *  - DATABASE_URL OR (PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE)
 *  - DB_POOL_MAX               default 10
 *  - DB_IDLE_MS                default 45000
 *  - DB_CONN_TIMEOUT_MS        default 5000
 *  - DB_SSL                    default false (set true to enable ssl { rejectUnauthorized:false })
 *  - DB_STATEMENT_TIMEOUT_MS   default 15000  (applied per session)
 *  - DB_IDLE_TX_TIMEOUT_MS     default 15000  (applied per session)
 *  - DB_TIMEZONE               default 'UTC'  (applied per session)
 */

function asBool(v: any, def = false) {
  if (v == null) return def;
  const s = String(v).trim().toLowerCase();
  return s === "1" || s === "true" || s === "yes" || s === "on";
}

const useUrl = !!process.env.DATABASE_URL;
const base = useUrl
  ? { connectionString: String(process.env.DATABASE_URL) }
  : {
      host: String(process.env.PGHOST ?? "localhost"),
      port: Number(process.env.PGPORT ?? 5432),
      user: String(process.env.PGUSER ?? ""),
      password: String(process.env.PGPASSWORD ?? ""),
      database: String(process.env.PGDATABASE ?? ""),
    };

const poolConfig = {
  ...base,
  max: Number(process.env.DB_POOL_MAX ?? 10),
  idleTimeoutMillis: Number(process.env.DB_IDLE_MS ?? 45_000),
  connectionTimeoutMillis: Number(process.env.DB_CONN_TIMEOUT_MS ?? 5_000),
  ssl: asBool(process.env.DB_SSL) ? { rejectUnauthorized: false } : undefined,
};

const SESSION_STATEMENT_TIMEOUT = Number(process.env.DB_STATEMENT_TIMEOUT_MS ?? 15_000);
const SESSION_IDLE_TX_TIMEOUT  = Number(process.env.DB_IDLE_TX_TIMEOUT_MS ?? 15_000);
const SESSION_TZ               = String(process.env.DB_TIMEZONE ?? "UTC");

/** Global singleton pool (hot-reload safe) */
declare global {
  // eslint-disable-next-line no-var
  var __core_pg_pool__: Pool | undefined;
}
export function getPool(): Pool {
  if (!global.__core_pg_pool__) {
    global.__core_pg_pool__ = new Pool(poolConfig as any);
    // set per-session parameters on connect
    global.__core_pg_pool__.on("connect", (client: PoolClient) => {
      client.query(`SET statement_timeout = ${SESSION_STATEMENT_TIMEOUT}`);
      client.query(`SET idle_in_transaction_session_timeout = ${SESSION_IDLE_TX_TIMEOUT}`);
      client.query(`SET TIME ZONE '${SESSION_TZ.replace(/'/g, "''")}'`);
    });
  }
  return global.__core_pg_pool__!;
}

/** Convenience export */
export const db = getPool();

/** Utility: get a client and ensure release */
export async function withClient<T>(fn: (c: PoolClient) => Promise<T>) {
  const c = await db.connect();
  try { return await fn(c); } finally { c.release(); }
}
