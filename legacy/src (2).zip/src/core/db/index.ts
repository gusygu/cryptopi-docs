// src/core/db/index.ts
export * from "./db";
export * from "./db.ref";
export * from "./session";
export * from "./ledger";
export * from "./migrate";
export * from "./cli";

// NEW: stage/commit + live-slice persistence helpers
export {
  stageMatrixGrid,
  commitMatrixGrid,
  persistLiveMatricesSlice,
  type MatrixGridObject,
  type MatrixType,
} from "./db";
