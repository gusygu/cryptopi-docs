"use client";

import React, { useEffect, useMemo, useState } from "react";
import HomeBar from "@/components/ui/HomeBar";
import DynamicsMatrix from "@/components/features/dynamics/DynamicsMatrix";
import AssetsIdentity from "@/components/features/dynamics/AssetsIdentity";
import AuxUi from "@/components/features/dynamics/AuxUi";
import ArbTable from "@/components/features/dynamics/ArbTable";
import CinAuxTable from "@/components/features/cin-aux/CinAuxTable";
import { formatNumber } from "@/components/features/dynamics/utils";
import { useSettings } from "@/lib/settings/provider";
import { useCoinsUniverse } from "@/lib/dynamicsClient";
import { useDomainVM, toArbTableInput, toMetricsPanel } from "@/core/converters/Converter.client";

const STORAGE_KEY = "dynamics:selectedPair";

function deriveDefaultPair(coins: string[]): { base: string; quote: string } {
  const upper = coins.map((c) => String(c).toUpperCase()).filter(Boolean);
  const base = upper[0] ?? "BTC";
  const quote = upper.find((c) => c !== base) ?? (base === "USDT" ? "BTC" : "USDT");
  return { base, quote };
}

export default function DynamicsPage() {
  const { settings } = useSettings() as any;
  const universe = useCoinsUniverse();

  const coins = useMemo<string[]>(
    () => (settings?.coinUniverse?.length ? settings.coinUniverse : universe).map((c: string) => String(c).toUpperCase()),
    [universe.join("|"), JSON.stringify(settings?.coinUniverse ?? [])]
  );

  const fallbackPair = useMemo(() => deriveDefaultPair(coins), [coins]);

  const [selected, setSelected] = useState<{ base: string; quote: string }>(() => fallbackPair);

  useEffect(() => {
    if (!coins.length) return;
    setSelected((prev) => {
      let base = (prev.base || fallbackPair.base).toUpperCase();
      let quote = (prev.quote || fallbackPair.quote).toUpperCase();
      if (!coins.includes(base)) {
        base = fallbackPair.base;
      }
      if (!coins.includes(quote) || quote === base) {
        const alt = coins.find((c) => c !== base);
        quote = alt ?? fallbackPair.quote;
      }
      if (quote === base) {
        const nextAlt = coins.find((c) => c !== base);
        if (nextAlt) quote = nextAlt;
      }
      return prev.base === base && prev.quote === quote ? prev : { base, quote };
    });
  }, [coins, fallbackPair.base, fallbackPair.quote]);

  useEffect(() => {
    if (typeof window === "undefined" || !coins.length) return;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as { base?: string; quote?: string };
      let base = String(parsed.base ?? "").toUpperCase();
      let quote = String(parsed.quote ?? "").toUpperCase();
      if (!coins.includes(base)) base = coins[0];
      if (!coins.includes(quote) || quote === base) {
        const alt = coins.find((c) => c !== base);
        quote = alt ?? fallbackPair.quote;
      }
      if (quote === base) {
        const nextAlt = coins.find((c) => c !== base);
        if (nextAlt) quote = nextAlt;
      }
      setSelected((prev) => (prev.base === base && prev.quote === quote ? prev : { base, quote }));
    } catch {
      /* ignore malformed local storage entry */
    }
  }, [coins, fallbackPair.quote]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!coins.includes(selected.base) || !coins.includes(selected.quote) || selected.base === selected.quote) return;
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ base: selected.base, quote: selected.quote })
    );
  }, [selected.base, selected.quote, coins]);

  const candidates = useMemo(
    () => coins.filter((c) => c !== selected.base && c !== selected.quote).slice(0, 12),
    [coins, selected.base, selected.quote]
  );

  const { vm, loading: vmLoading, error: vmError, refresh: refreshVM } = useDomainVM(
    selected.base,
    selected.quote,
    coins,
    candidates
  );

  const { rows: arbRows, wallets } = useMemo(() => toArbTableInput(vm), [vm]);
  const metricsPanel = useMemo(() => toMetricsPanel(vm), [vm]);

  const pairLabel = `${selected.base}/${selected.quote}`;

  return (
    <div className="min-h-dvh">
      <HomeBar className="sticky top-0 z-30" />
      <main className="cp-maxw p-4 lg:p-6 space-y-6">
        <header className="space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="cp-h1">Dynamics Workspace</h1>
            <div className="ml-auto flex flex-wrap items-center gap-2 text-xs">
              <span className="cp-pill-emerald">{pairLabel}</span>
              <span className="cp-pill-silver">coins {coins.length}</span>
              <span className="cp-pill-silver">candidates {candidates.length}</span>
            </div>
          </div>
          <p className="text-sm cp-subtle max-w-3xl">
            Hybrid layout mirrors the legacy dynamics dashboard: MEA matrix and identity panels on top, auxiliary controls and
            arbitrage explorer below, all reskinned with the emerald and silver palette.
          </p>
        </header>

        <section className="grid grid-cols-12 gap-6">
          <div className="col-span-12 xl:col-span-7">
            <div className="cp-card">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <div className="text-sm text-[var(--cp-silver-1)]">Dynamics - MEA Matrix</div>
                  <div className="text-[11px] cp-subtle">Select any non-diagonal cell to change the active pair.</div>
                </div>
              </div>
              <DynamicsMatrix
                coins={coins}
                base={selected.base}
                quote={selected.quote}
                onSelect={(b, q) => setSelected({ base: b, quote: q })}
                autoRefreshMs={40_000}
                title="Dynamics - MEA Matrix"
              />
            </div>
          </div>

          <div className="col-span-12 xl:col-span-5 space-y-4">
            <div className="cp-card">
              <div className="mb-3 text-sm text-[var(--cp-silver-1)]">Pair summary</div>
              <div className="grid gap-2 text-xs">
                <div className="flex flex-wrap gap-2">
                  <span className="cp-pill-emerald">Base {selected.base}</span>
                  <span className="cp-pill-emerald">Quote {selected.quote}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="cp-pill-silver">Universe coins {coins.length}</span>
                  <span className="cp-pill-silver">Arb candidates {candidates.length}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="cp-pill-silver">MEA {formatNumber(metricsPanel.mea.value, { precision: 4 })}</span>
                  <span className="cp-pill-emerald">Tier {metricsPanel.mea.tier}</span>
                </div>
                {vmLoading ? (
                  <div className="text-[11px] text-slate-400">Loading converter snapshot…</div>
                ) : null}
                {vmError ? (
                  <div className="text-[11px] text-rose-300">{vmError}</div>
                ) : null}
              </div>
            </div>
            <div className="cp-card">
              <AssetsIdentity base={selected.base} quote={selected.quote} wallets={wallets} autoRefreshMs={40_000} />
            </div>
          </div>
        </section>

        <section className="grid grid-cols-12 gap-6">
          <div className="col-span-12 xl:col-span-7">
            <AuxUi
              coins={coins}
              base={selected.base}
              quote={selected.quote}
              onSelectPair={(b, q) => setSelected({ base: b, quote: q })}
            />
          </div>
          <div className="col-span-12 xl:col-span-5">
            <ArbTable
              Ca={selected.base}
              Cb={selected.quote}
              candidates={candidates}
              wallets={wallets}
              rows={arbRows}
              loading={vmLoading}
              refreshing={vmLoading && arbRows.length > 0}
              onRefresh={refreshVM}
              onRowClick={(ci) =>
                setSelected((prev) => (prev.quote === ci ? prev : { base: prev.base, quote: ci }))
              }
            />
          </div>
        </section>

        <section className="cp-card">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-sm text-[var(--cp-silver-1)]">CIN Auxiliary snapshot</div>
            <div className="text-[11px] cp-subtle">Filtered to active pair only.</div>
          </div>
          <CinAuxTable clusterCoins={[selected.base, selected.quote]} />
        </section>
      </main>
    </div>
  );
}
