import { NextResponse } from 'next/server';

export async function GET() {
  const ts = Date.now();
  return NextResponse.json({
    ok: true,
    ts,
    routes: {
      providers: '/api/market/providers',
      wallet: '/api/market/wallet',
      ticker: '/api/market/ticker',
      pairs: '/api/market/pairs',
      preview: '/api/market/preview',
      previewSymbols: '/api/market/preview/symbols',
      sources: '/api/market/sources',
    },
  }, { headers: { 'Cache-Control': 'no-store' } });
}
