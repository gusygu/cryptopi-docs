// SETTINGS-conditioned preview symbols.
// Defaults to the user's current selection (cookies / server settings) but allows
// overriding via ?coins=BTC,ETH or POST { coins: [...] }.
//
// GET  /api/market/preview/symbols
// GET  /api/market/preview/symbols?coins=BTC,ETH,SOL
// POST /api/market/preview/symbols   (body: { coins: string[] })
//
// Response:
// { ok: true, source: 'local'|'exchangeInfo'|'ticker'|'empty', symbols: string[] }

import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

type AnyRec = Record<string, unknown>;

const toUpper = (v: unknown) => String(v ?? '').trim().toUpperCase();
const toUpperList = (xs: unknown) =>
  Array.isArray(xs) ? xs.map(toUpper).filter(Boolean) : [];

function basesToUsdtSymbols(bases: string[]): string[] {
  const out: string[] = [];
  for (const b of bases) {
    const u = toUpper(b);
    if (!u) continue;
    out.push(u.endsWith('USDT') ? u : `${u}USDT`);
  }
  return Array.from(new Set(out));
}

async function resolveCoinsFromSettingsSafely(): Promise<string[]> {
  // dynamic import to avoid hard failures if the file location/name changes
  try {
    const mod: AnyRec = await import('@/lib/settings/server');
    const fn = typeof mod.resolveCoinsFromSettings === 'function' ? mod.resolveCoinsFromSettings : null;
    if (fn) {
      const arr = await fn();
      return Array.isArray(arr) ? arr.map(toUpper).filter(Boolean) : [];
    }
  } catch {
    // fall through to env default
  }
  const env = toUpper(process.env.NEXT_PUBLIC_COINS ?? '');
  const bases = env ? env.split(/[,\s]+/).filter(Boolean) : ['BTC', 'ETH', 'BNB', 'SOL', 'ADA', 'XRP', 'DOGE'];
  return bases;
}

// Local curated provider (optional). If present, it may already return symbols.
async function tryLocalPreview(origin: string): Promise<string[]> {
  try {
    const r = await fetch(`${origin}/api/market/providers/binance/preview`, { cache: 'no-store' });
    if (!r.ok) return [];
    const j = (await r.json()) as AnyRec;
    const candidates =
      toUpperList((j as AnyRec).symbols) ||
      toUpperList((j as AnyRec).pairs) ||
      toUpperList((j as AnyRec).preview) ||
      toUpperList((j as AnyRec).list) ||
      toUpperList((j as AnyRec).allowed) ||
      toUpperList((j as AnyRec).data) ||
      toUpperList((j as AnyRec).result);
    return candidates;
  } catch {
    return [];
  }
}

async function filterWithExchangeInfo(candidates: string[]): Promise<string[]> {
  try {
    const r = await fetch('https://api.binance.com/api/v3/exchangeInfo', { cache: 'no-store' });
    if (!r.ok) return [];
    const j = (await r.json()) as AnyRec;
    const list = Array.isArray(j.symbols) ? (j.symbols as AnyRec[]) : [];
    const tradable = new Set<string>(
      list
        .map((row) => (row && typeof row === 'object' ? row : null))
        .filter((row): row is AnyRec => !!row)
        .filter((row) => toUpper(row.status) === 'TRADING')
        .map((row) => toUpper((row as AnyRec).symbol))
        .filter(Boolean)
    );
    return candidates.filter((s) => tradable.has(s));
  } catch {
    return [];
  }
}

async function filterWith24hTicker(candidates: string[]): Promise<string[]> {
  const checks = await Promise.allSettled(
    candidates.map(async (sym) => {
      const r = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${sym}`, { cache: 'no-store' });
      return r.ok ? sym : '';
    })
  );
  const ok: string[] = [];
  for (const c of checks) if (c.status === 'fulfilled' && c.value) ok.push(c.value);
  return ok;
}

async function resolveSymbolsFromBases(bases: string[], origin: string) {
  // 1) try local curated provider
  const local = await tryLocalPreview(origin);
  if (local.length) return { source: 'local' as const, symbols: Array.from(new Set(local)) };

  // 2) exchangeInfo
  const candidates = basesToUsdtSymbols(bases);
  const s1 = await filterWithExchangeInfo(candidates);
  if (s1.length) return { source: 'exchangeInfo' as const, symbols: Array.from(new Set(s1)) };

  // 3) ticker fallback
  const s2 = await filterWith24hTicker(candidates);
  if (s2.length) return { source: 'ticker' as const, symbols: Array.from(new Set(s2)) };

  return { source: 'empty' as const, symbols: [] as string[] };
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const bases = url.searchParams.get('coins')
    ? url.searchParams.get('coins')!.split(',').map(toUpper).filter(Boolean)
    : await resolveCoinsFromSettingsSafely();

  if (!bases.length) {
    return NextResponse.json({ ok: true, source: 'empty', symbols: [] }, { headers: { 'Cache-Control': 'no-store' } });
  }

  const { source, symbols } = await resolveSymbolsFromBases(bases, url.origin);
  return NextResponse.json({ ok: true, source, symbols }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(req: Request) {
  try {
    const url = new URL(req.url);
    const body = (await req.json()) as { coins?: unknown };
    const bases = toUpperList(body?.coins);
    if (!bases.length) {
      // fall back to settings selection
      const sel = await resolveCoinsFromSettingsSafely();
      if (!sel.length) return NextResponse.json({ ok: true, source: 'empty', symbols: [] }, { headers: { 'Cache-Control': 'no-store' } });
      const { source, symbols } = await resolveSymbolsFromBases(sel, url.origin);
      return NextResponse.json({ ok: true, source, symbols }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const { source, symbols } = await resolveSymbolsFromBases(bases, url.origin);
    return NextResponse.json({ ok: true, source, symbols }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'invalid payload';
    return NextResponse.json({ ok: false, error: msg }, { status: 400, headers: { 'Cache-Control': 'no-store' } });
  }
}
