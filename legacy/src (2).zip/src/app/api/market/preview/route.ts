// ALL previewable symbols (universe or explicit ?coins=)
// No settings filtering here — just “what symbols exist on Binance” for the given bases.
//
// GET  /api/market/preview
// GET  /api/market/preview?coins=BTC,ETH,SOL
// POST /api/market/preview   (body: { coins: string[] })
//
// Response:
// { ok: true, source: 'exchangeInfo'|'ticker'|'empty', symbols: string[] }

import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

// ---------- local helpers (self-contained to avoid TS drift) -----------------
type AnyRec = Record<string, unknown>;

const toUpper = (v: unknown) => String(v ?? '').trim().toUpperCase();
const toUpperList = (xs: unknown) =>
  Array.isArray(xs) ? xs.map(toUpper).filter(Boolean) : [];

function basesToUsdtSymbols(bases: string[]): string[] {
  const out: string[] = [];
  for (const b of bases) {
    const u = toUpper(b);
    if (!u) continue;
    out.push(u.endsWith('USDT') ? u : `${u}USDT`);
  }
  // de-dup
  return Array.from(new Set(out));
}

function parseCoinsParam(url: URL): string[] {
  const q = url.searchParams.get('coins');
  if (q && q.trim()) {
    return q.split(',').map(toUpper).filter(Boolean);
  }
  // fallback to env / simple defaults
  const env = toUpper(process.env.NEXT_PUBLIC_COINS ?? '');
  const bases = env ? env.split(/[,\s]+/).filter(Boolean) : ['BTC', 'ETH', 'BNB', 'SOL', 'ADA', 'XRP', 'DOGE'];
  return bases;
}

// Uses exchangeInfo as the primary filter (TRADING status)
async function filterWithExchangeInfo(candidates: string[]): Promise<string[]> {
  try {
    const r = await fetch('https://api.binance.com/api/v3/exchangeInfo', { cache: 'no-store' });
    if (!r.ok) return [];
    const j = (await r.json()) as AnyRec;
    const list = Array.isArray(j.symbols) ? (j.symbols as AnyRec[]) : [];
    const tradable = new Set<string>(
      list
        .map((row) => (row && typeof row === 'object' ? row : null))
        .filter((row): row is AnyRec => !!row)
        .filter((row) => toUpper(row.status) === 'TRADING')
        .map((row) => toUpper((row as AnyRec).symbol))
        .filter(Boolean)
    );
    return candidates.filter((s) => tradable.has(s));
  } catch {
    return [];
  }
}

// Fallback: probe 24h ticker for each candidate (200 => exists)
async function filterWith24hTicker(candidates: string[]): Promise<string[]> {
  const checks = await Promise.allSettled(
    candidates.map(async (sym) => {
      const r = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${sym}`, { cache: 'no-store' });
      return r.ok ? sym : '';
    })
  );
  const ok: string[] = [];
  for (const c of checks) if (c.status === 'fulfilled' && c.value) ok.push(c.value);
  return ok;
}

// ---------- handlers ----------------------------------------------------------
async function resolveSymbolsFromBases(bases: string[]) {
  const candidates = basesToUsdtSymbols(bases);
  if (!candidates.length) return { source: 'empty' as const, symbols: [] as string[] };

  const s1 = await filterWithExchangeInfo(candidates);
  if (s1.length) return { source: 'exchangeInfo' as const, symbols: Array.from(new Set(s1)) };

  const s2 = await filterWith24hTicker(candidates);
  if (s2.length) return { source: 'ticker' as const, symbols: Array.from(new Set(s2)) };

  return { source: 'empty' as const, symbols: [] as string[] };
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const bases = parseCoinsParam(url);
  const { source, symbols } = await resolveSymbolsFromBases(bases);
  return NextResponse.json({ ok: true, source, symbols }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { coins?: unknown };
    const bases = toUpperList(body?.coins);
    if (!bases.length) {
      return NextResponse.json({ ok: true, source: 'empty', symbols: [] }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const { source, symbols } = await resolveSymbolsFromBases(bases);
    return NextResponse.json({ ok: true, source, symbols }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'invalid payload';
    return NextResponse.json({ ok: false, error: msg }, { status: 400, headers: { 'Cache-Control': 'no-store' } });
  }
}
