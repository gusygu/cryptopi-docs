import { NextResponse } from 'next/server';

const PROVIDERS = [
  {
    id: 'binance',
    name: 'Binance',
    routes: {
      wallet: '/api/market/providers/binance/wallet',
      preview: '/api/market/providers/binance/preview',
      accountTest: '/api/market/providers/binance/account/test',
    },
  },
];

export async function GET() {
  return NextResponse.json({ providers: PROVIDERS, count: PROVIDERS.length }, {
    headers: { 'Cache-Control': 'no-store' },
  });
}
