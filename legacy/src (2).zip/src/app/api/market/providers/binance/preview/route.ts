import { NextResponse } from 'next/server';
import { getBinancePreviewCoins } from '@/core/api/market/binance';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const quote = searchParams.get('quote') ?? undefined;
  const spotOnly = (searchParams.get('spot') ?? '1') !== '0';

  try {
    const payload = await getBinancePreviewCoins({ quote, spotOnly });

    return NextResponse.json({
      coins: payload.coins,
      count: payload.coins.length,
      source: 'binance',
      cached: payload.cached,
      updatedAt: payload.updatedAt,
      note: payload.note,
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'preview fetch failed';
    return NextResponse.json(
      {
        coins: [],
        count: 0,
        source: 'binance',
        error: message,
      },
      { status: 502, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
