// src/app/api/matrices/commit/route.ts
import { NextResponse } from "next/server";
import { getPool } from "@/core/db/pool";

export const dynamic = "force-dynamic";
export const revalidate = 0;

type Row = { base: string; quote: string; value: number; meta?: any };
type Body = {
  app_session_id: string;
  matrix_type: "benchmark"|"delta"|"pct24h"|"id_pct"|"pct_drv"|"pct_ref"|"ref";
  ts_ms: number;
  rows: Row[];
  coins_override?: string[];         // optional ["BTC","ETH",...]; if absent, uses settings coins
  idem?: string;                     // optional idempotency key
};

const NO_STORE = {
  "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
  Pragma: "no-cache",
  Expires: "0",
};

export async function POST(req: Request) {
  const cycleId = `commit-${Date.now()}`;
  try {
    const body = await req.json() as Body;
    const { app_session_id, matrix_type, ts_ms, rows, coins_override, idem } = body;

    if (!app_session_id || !matrix_type || !ts_ms || !Array.isArray(rows) || !rows.length) {
      return NextResponse.json({ ok:false, error:"missing fields" }, { status: 400, headers: NO_STORE });
    }

    // stage rows
    const client = await getPool().connect();
    try {
      await client.query("BEGIN");
      const text = `
        INSERT INTO public.dyn_matrix_values_stage(ts_ms, matrix_type, base, quote, value, meta, app_session_id)
        VALUES ($1,$2,$3,$4,$5,COALESCE($6,'{}'::jsonb),$7)
        ON CONFLICT (ts_ms, matrix_type, base, quote)
        DO UPDATE SET value=EXCLUDED.value, meta=EXCLUDED.meta, app_session_id=EXCLUDED.app_session_id
      `;
      for (const r of rows) {
        if (!r || !r.base || !r.quote || r.base.toUpperCase()===r.quote.toUpperCase()) continue;
        await client.query(text, [ts_ms, matrix_type, r.base.toUpperCase(), r.quote.toUpperCase(), Number(r.value), r.meta ?? {}, app_session_id]);
      }

      // commit + validate
      const res = await client.query<{ commit_matrix_grid: any }>(
        `SELECT public.commit_matrix_grid($1,$2,$3,$4,$5)`,
        [app_session_id, matrix_type, ts_ms, coins_override ? JSON.stringify(coins_override) : null, idem ?? null]
      );
      await client.query("COMMIT");
      return NextResponse.json({ ok:true, report: res.rows[0].commit_matrix_grid }, { headers: { ...NO_STORE, "x-cycle-id": cycleId } });
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
  } catch (e: any) {
    return NextResponse.json({ ok:false, error:String(e?.message ?? e) }, { status: 500, headers: { ...NO_STORE, "x-cycle-id": cycleId } });
  }
}
