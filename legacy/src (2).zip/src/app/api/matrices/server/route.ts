// src/app/api/matrices/server/route.ts
export { dynamic } from "../route";
export { GET } from "../route";
