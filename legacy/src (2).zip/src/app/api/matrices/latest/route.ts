// app/api/matrices/latest/route.ts

import { NextResponse } from "next/server";
import { cookies, headers } from "next/headers";
import { db } from "@/core/db/db";
import { liveFromSources } from "@/core/features/matrices/liveFromSources";
import {
  configureBenchmarkProviders,
  computeFromDbAndLive,
} from "@/core/maths/math";
import { fetchOpeningGridFromView } from "@/core/features/matrices/opening";
import { resolveCoinsFromSettings } from "@/lib/settings/server";

const ALLOWED_WINDOWS = new Set(["15m", "30m", "1h"] as const);
type MatrixWindow = "15m" | "30m" | "1h";

const normalizeCoins = (xs: readonly string[]) =>
  Array.from(new Set(xs.map((s) => s.trim().toUpperCase()).filter(Boolean)));

function parseCoinsCSV(csv: string | null | undefined): string[] | null {
  if (!csv) return null;
  return normalizeCoins(csv.split(","));
}

function parseCoinsJSON(jsonStr: string | null | undefined): string[] | null {
  if (!jsonStr) return null;
  try {
    const xs = JSON.parse(jsonStr);
    if (!Array.isArray(xs)) return null;
    return normalizeCoins(xs);
  } catch {
    return null;
  }
}

function coinsAddUSDTFirst(userCoins: readonly string[]) {
  const xs = normalizeCoins(userCoins);
  const withoutUSDT = xs.filter((c) => c !== "USDT");
  return ["USDT", ...withoutUSDT];
}

function coinsFromCookiesOrHeaders(): string[] | null {
  const bagCookies = cookies();
  const bagHeaders = headers();

  const ckJson = bagCookies.get("cp_coins")?.value; // JSON array
  const ckCsv = bagCookies.get("cp.coins")?.value; // CSV
  const fromCkJson = parseCoinsJSON(ckJson);
  const fromCkCsv = parseCoinsCSV(ckCsv);
  if (fromCkJson?.length) return fromCkJson;
  if (fromCkCsv?.length) return fromCkCsv;

  const hxCsv = bagHeaders.get("x-cp-coins");
  const hxJson = bagHeaders.get("x-cp-coins-json");
  const fromHxCsv = parseCoinsCSV(hxCsv ?? undefined);
  const fromHxJson = parseCoinsJSON(hxJson ?? undefined);
  if (fromHxJson?.length) return fromHxJson;
  if (fromHxCsv?.length) return fromHxCsv;

  return null;
}

async function resolveCoinsUniverse(preferred: string[] | null): Promise<string[]> {
  if (preferred && preferred.length) return coinsAddUSDTFirst(preferred);

  const legacy = coinsFromCookiesOrHeaders();
  if (legacy?.length) return coinsAddUSDTFirst(legacy);

  const fromSettings = await resolveCoinsFromSettings();
  if (fromSettings.length) return coinsAddUSDTFirst(fromSettings);

  return ["USDT"];
}

function ensureWindow(win: string | null | undefined): MatrixWindow {
  if (!win) return "30m";
  const lc = win.toLowerCase();
  return ALLOWED_WINDOWS.has(lc as MatrixWindow)
    ? (lc as MatrixWindow)
    : "30m";
}

type MatValues = Record<string, Record<string, number | null>>;

type MatricesLatestSuccessPayload = {
  ok: true;
  coins: string[];
  symbols: string[];
  quote: string;
  window: MatrixWindow;
  ts: number;
  matrices: {
    benchmark: { ts: number; values: MatValues; flags?: any };
    pct24h: { ts: number; values: MatValues; flags?: any };
    id_pct: { ts: number; values: MatValues };
    pct_drv: { ts: number; values: MatValues };
    pct_ref: { ts: number; values: MatValues };
    ref: { ts: number; values: MatValues };
    delta: { ts: number; values: MatValues };
  };
  meta: {
    openingTs: number | null;
    universe: string[];
  };
};

type MatricesLatestErrorPayload = {
  ok: false;
  error: string;
};

export type MatricesLatestPayload =
  | MatricesLatestSuccessPayload
  | MatricesLatestErrorPayload;

function toGrid(
  coins: readonly string[],
  values: MatValues
): (number | null)[][] {
  const n = coins.length;
  const grid: (number | null)[][] = Array.from({ length: n }, () =>
    Array.from({ length: n }, () => null)
  );
  for (let i = 0; i < n; i++) {
    const bi = coins[i]!;
    const row = values[bi] || {};
    for (let j = 0; j < n; j++) {
      if (i === j) continue;
      const qj = coins[j]!;
      const v = row[qj];
      grid[i][j] = v == null ? null : Number(v);
    }
  }
  return grid;
}

function toValues(
  coins: readonly string[],
  grid: (number | null)[][]
): MatValues {
  const out: MatValues = {};
  for (let i = 0; i < coins.length; i++) {
    const bi = coins[i]!;
    out[bi] = {} as any;
    for (let j = 0; j < coins.length; j++) {
      if (i === j) continue;
      const qj = coins[j]!;
      out[bi][qj] = grid[i][j] ?? null;
    }
  }
  return out;
}

function parseQuery(req: Request): {
  coins: string[] | null;
  quote: string;
  window: MatrixWindow;
  appSessionId: string | null;
} {
  const url = new URL(req.url);
  const qCoins = parseCoinsCSV(url.searchParams.get("coins"));
  const quote = (url.searchParams.get("quote") || "USDT").toUpperCase();
  const window = ensureWindow(url.searchParams.get("window"));
  const appSessionId = url.searchParams.get("appSessionId") || null;
  return { coins: qCoins, quote, window, appSessionId };
}

type BuildMatricesLatestArgs = {
  coins?: string[] | null;
  quote?: string;
  window?: string | null;
  appSessionId?: string | null;
};

const pickValues = (coins: readonly string[], vals: MatValues): MatValues => {
  const toKeep = coins;
  const out: MatValues = {};
  for (const b of toKeep) {
    const row = vals[b] || {};
    const dst: Record<string, number | null> = {};
    for (const q of toKeep) {
      if (b === q) continue;
      if (Object.prototype.hasOwnProperty.call(row, q)) {
        dst[q] = row[q]!;
      }
    }
    out[b] = dst;
  }
  return out;
};

export async function buildMatricesLatestPayload(
  params: BuildMatricesLatestArgs = {}
): Promise<MatricesLatestPayload> {
  const quote = (params.quote ?? "USDT").toUpperCase();
  const window = ensureWindow(params.window ?? null);
  const appSessionId = params.appSessionId ?? null;

  try {
    const queryCoinsNormalized = Array.isArray(params.coins)
      ? normalizeCoins(params.coins)
      : null;

    const coins = await resolveCoinsUniverse(
      queryCoinsNormalized && queryCoinsNormalized.length
        ? queryCoinsNormalized
        : null
    );

    if (!coins.length) {
      throw new Error("No coins resolved for matrices universe");
    }

    const live = await liveFromSources(coins);

    let lastOpeningTs: number | null = null;

    configureBenchmarkProviders({
      getPrev: async (matrix_type, base, quoteSym, beforeTs) => {
        const { rows } = await db.query<{ value: string }>(
          `
          select value::text as value
            from public.dyn_matrix_values
           where matrix_type = $1
             and base = $2 and quote = $3
             and ts_ms < $4
        order by ts_ms desc
           limit 1
          `,
          [matrix_type, base.toUpperCase(), quoteSym.toUpperCase(), beforeTs]
        );
        if (!rows?.length) return null;
        const v = Number(rows[0]!.value);
        return Number.isFinite(v) ? v : null;
      },

      fetchOpeningGrid: async (coinsUniverse, nowTs) => {
        const ref = await fetchOpeningGridFromView({
          coins: coinsUniverse,
          window,
          appSessionId,
          openingTs: undefined,
        });
        lastOpeningTs = ref.ts ?? nowTs;
        return { ts: ref.ts ?? nowTs, grid: ref.grid };
      },
    });

    const bmGrid = toGrid(coins, live.matrices.benchmark.values);
    const nowTs = live.matrices.benchmark.ts;

    const derived = await computeFromDbAndLive({
      coins: coins.slice(),
      nowTs,
      liveBenchmark: bmGrid,
    });

    const bmValues = pickValues(coins, live.matrices.benchmark.values);
    const pct24Values = pickValues(coins, live.matrices.pct24h.values);
    const idPctValues = toValues(coins, derived.id_pct);
    const drvValues = toValues(coins, derived.pct_drv);
    const pctRefValues = toValues(coins, derived.pct_ref);
    const refValues = toValues(coins, derived.ref);
    const deltaValues = toValues(coins, derived.delta);

    const symbols: string[] = [];
    for (let i = 0; i < coins.length; i++) {
      for (let j = 0; j < coins.length; j++) {
        if (i === j) continue;
        symbols.push(`${coins[i]}${coins[j]}`);
      }
    }

    const coinsDisplay = coins.filter((c) => c !== quote);

    return {
      ok: true,
      coins: coinsDisplay,
      symbols,
      quote,
      window,
      ts: nowTs,
      matrices: {
        benchmark: {
          ts: nowTs,
          values: bmValues,
          flags: live.matrices.benchmark.flags,
        },
        pct24h: {
          ts: nowTs,
          values: pct24Values,
          flags: live.matrices.pct24h.flags,
        },
        id_pct: { ts: nowTs, values: idPctValues },
        pct_drv: { ts: nowTs, values: drvValues },
        pct_ref: { ts: nowTs, values: pctRefValues },
        ref: { ts: nowTs, values: refValues },
        delta: { ts: nowTs, values: deltaValues },
      },
      meta: {
        openingTs: lastOpeningTs,
        universe: coins,
      },
    } satisfies MatricesLatestSuccessPayload;
  } catch (err: any) {
    console.error("[matrices/latest] error:", err);
    return {
      ok: false,
      error: String(err?.message ?? err),
    } satisfies MatricesLatestErrorPayload;
  }
}

export async function GET(req: Request) {
  const q = parseQuery(req);
  const payload = await buildMatricesLatestPayload(q);
  const status = payload.ok ? 200 : 500;
  return NextResponse.json(payload, { status });
}