// src/app/api/str-aux/stats/route.ts
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import { computeStats, type Point as StatPoint } from '@/core/features/str-aux/calc/stats';
import { applyGfmShiftAndStreams, type ShiftWindowState, type StreamsState } from '@/core/features/str-aux/frame/analytics';
import { resolveCoinsFromSettings } from '@/lib/settings/server';
import { dedupeCoins, normalizeCoin } from '@/lib/markets/pairs';

// ───────────────────────── helpers ─────────────────────────
type WindowKey = '30m' | '1h' | '3h';
type Interval = '1m' | '5m';
type Kline = [number, string, string, string, string, string, number, string, number, string, string, string];

const U = (x: unknown) => String(x ?? '').trim().toUpperCase();
const KNOWN_QUOTES = ['USDT','BTC','ETH','BNB','BUSD','FDUSD','USDC','TUSD'] as const;

function splitSymbol(sym: string): { base: string; quote: string } {
  const S = U(sym);
  for (const q of KNOWN_QUOTES) if (S.endsWith(q) && S.length > q.length) return { base: S.slice(0, -q.length), quote: q };
  return { base: S.replace(/USDT$/i, ''), quote: 'USDT' };
}
function parseWindow(s: string | null | undefined): WindowKey {
  const v = (s ?? '30m').toLowerCase();
  return (v === '30m' || v === '1h' || v === '3h') ? (v as WindowKey) : '30m';
}
function windowToInterval(w: WindowKey): { interval: Interval; limit: number } {
  switch (w) {
    case '30m': return { interval: '1m', limit: 120 };
    case '1h':  return { interval: '1m', limit: 240 };
    case '3h':  return { interval: '5m', limit: 180 };
    default:    return { interval: '1m', limit: 120 };
  }
}
function parseBinsParam(s: string | null | undefined, dflt = 128) {
  const n = Number(s ?? dflt);
  return Number.isFinite(n) && n > 0 ? Math.min(2048, Math.floor(n)) : dflt;
}
function toUSDT(symOrBase: string) {
  const base = normalizeCoin(symOrBase);
  if (!base) return '';
  return base === 'USDT' ? 'USDT' : `${base}USDT`;
}

async function getPreviewSymbols(origin: string): Promise<string[]> {
  try {
    const r = await fetch(`${origin}/api/market/preview`, { cache: 'no-store' });
    if (!r.ok) return [];
    const j = await r.json() as any;
    return Array.isArray(j?.symbols) ? j.symbols.map(U) : [];
  } catch { return []; }
}
async function getSettingsSymbols(origin: string): Promise<string[]> {
  try {
    const r = await fetch(`${origin}/api/market/preview/symbols`, { cache: 'no-store' });
    if (!r.ok) return [];
    const j = await r.json() as any;
    return Array.isArray(j?.symbols) ? j.symbols.map(U) : [];
  } catch { return []; }
}
async function resolveBasesFromSettings(origin: string): Promise<string[]> {
  const fromSettings = dedupeCoins(await resolveCoinsFromSettings()).filter((c) => c !== 'USDT');
  if (fromSettings.length) return fromSettings;

  const setSyms = await getSettingsSymbols(origin);
  if (setSyms.length) {
    const bases = dedupeCoins(setSyms.map((s) => splitSymbol(s).base)).filter((c) => c !== 'USDT');
    if (bases.length) return bases;
  }

  const uniSyms = await getPreviewSymbols(origin);
  if (uniSyms.length) {
    const bases = dedupeCoins(uniSyms.map((s) => splitSymbol(s).base)).filter((c) => c !== 'USDT');
    if (bases.length) return bases;
  }

  const env = U(process.env.NEXT_PUBLIC_COINS ?? '');
  const envBases = env
    ? dedupeCoins(env.split(/[,\s]+/).filter(Boolean)).filter((c) => c !== 'USDT')
    : [];
  if (envBases.length) return envBases;

  return dedupeCoins(['BTC','ETH','BNB','SOL','ADA','XRP','DOGE']).filter((c) => c !== 'USDT');
}
async function resolveSymbols(url: URL): Promise<string[]> {
  const symQ = url.searchParams.get('symbols');
  if (symQ && symQ.trim()) {
    return Array.from(new Set(symQ.split(',').map(U).filter(s => /^[A-Z0-9]{5,20}$/.test(s))));
  }
  const q = url.searchParams.get('bases');
  if (q && q.trim()) {
    return Array.from(new Set(q.split(',').map(toUSDT).filter(Boolean)));
  }
  const bases = await resolveBasesFromSettings(url.origin);
  return Array.from(new Set(bases.map(toUSDT).filter(Boolean)));
}

async function fetchTicker24h(symbol: string) {
  const r = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}`, { cache: 'no-store' });
  if (!r.ok) return { price: NaN, pct24h: NaN };
  const j = await r.json() as any;
  const price = Number(j.lastPrice ?? j.weightedAvgPrice ?? NaN);
  const pct24h = Number(j.priceChangePercent ?? NaN);
  return { price, pct24h };
}
async function fetchKlines(symbol: string, interval: Interval, limit: number): Promise<Array<{ts:number;price:number;volume?:number}>> {
  const r = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, { cache: 'no-store' });
  if (!r.ok) return [];
  const rows = await r.json() as Kline[];
  return rows.map(k => ({ ts: k[0], price: Number(k[4]), volume: Number(k[5]) })).filter(p => Number.isFinite(p.price));
}

function makeCounts(points: {price:number}[], opening: number, totalBins: number): number[] {
  if (!points.length || !(opening > 0) || totalBins <= 0) return Array(totalBins).fill(0);
  const rets = points.map(p => Math.log(p.price / opening));
  const min = Math.min(...rets), max = Math.max(...rets);
  const lo = min === max ? min - 1e-6 : min, hi = min === max ? max + 1e-6 : max;
  const bins = Array(totalBins).fill(0);
  for (const r of rets) {
    const t = (r - lo) / (hi - lo);
    const idx = Math.max(0, Math.min(totalBins - 1, Math.floor(t * totalBins)));
    bins[idx] += 1;
  }
  return bins;
}
function pctDrv(prev: number, cur: number): number { return 100 * ((cur / prev) - 1); }
function benchPct(opening: number, cur: number): number { return 100 * ((cur / opening) - 1); }

// ─────────── in-memory shift store (normalized gfm in [0..1]) ───────────
type ShiftStore = { refGfm01: number; window: ShiftWindowState; streams: StreamsState; uiEpoch: number; shifts: number; };
declare global { var __STR_AUX_SHIFT__: Map<string, ShiftStore> | undefined; }
const SHIFT: Map<string, ShiftStore> = (globalThis as any).__STR_AUX_SHIFT__ ?? new Map();
(globalThis as any).__STR_AUX_SHIFT__ = SHIFT;
const shiftKey = (sess: string, sym: string) => `${sess}:${sym}`;
function getShiftState(appSessionId: string, symbol: string): ShiftStore {
  const key = shiftKey(appSessionId, symbol);
  const cur = SHIFT.get(key);
  if (cur) return cur;
  const init: ShiftStore = { refGfm01: 0.5, window: { exceed: [], shifts: 0 }, streams: { maxStamps: 64 }, uiEpoch: 0, shifts: 0 };
  SHIFT.set(key, init);
  return init;
}

// ───────────────────────── route ─────────────────────────
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const symbols = await resolveSymbols(url);
    const windowKey = parseWindow(url.searchParams.get('window'));
    const binsN = parseBinsParam(url.searchParams.get('bins'), 128);
    const appSessionId = (url.searchParams.get('sessionId') ?? 'ui').slice(0, 64);
    const epsPct = Number(url.searchParams.get('eps') ?? '0.35');
    const kCycles = Math.max(1, Math.floor(Number(url.searchParams.get('k') ?? '5')));
    const { interval, limit } = windowToInterval(windowKey);
    const now = Date.now();

    if (!symbols.length) {
      return NextResponse.json({ ok: true, symbols: [], out: {}, window: windowKey, ts: now });
    }

    const out: Record<string, any> = {};

    for (const symbol of symbols) {
      const { base, quote } = splitSymbol(symbol);
      try {
        const [t24, series] = await Promise.all([
          fetchTicker24h(symbol),
          fetchKlines(symbol, interval, limit),
        ]);
        if (!series.length) {
          out[symbol] = { ok: false, error: 'no klines', bins: binsN, window: windowKey };
          continue;
        }

        // prepare series/refs
        const last = series[series.length - 1];
        const prev = series[series.length - 2] ?? last;
        const opening = series[0].price;
        const points: StatPoint[] = series.map(p => ({ ts: p.ts, price: p.price, volume: p.volume ?? 0 }));

        const priceMin = Math.min(...series.map(p => p.price));
        const priceMax = Math.max(...series.map(p => p.price));
        const benchSeries = series.map(p => benchPct(opening, p.price));
        const benchPctMin = Math.min(...benchSeries);
        const benchPctMax = Math.max(...benchSeries);

        // compute stats (FloMo absolute & BFloM 0..1 come from stats.ts)  ⟶ use normalized BFloM for shift logic
        const stats = computeStats(points, { benchmark: opening }, {
          idhr: { bins: binsN, alpha: 2.5, sMin: 1e-6, smooth: 3, topK: 8 },
          epsGfmPct: epsPct, epsBfmPct: epsPct,
          vScale: 100, tendencyWin: 30, tendencyNorm: 'mad',
        }); // uses your rehydrated stats module. :contentReference[oaicite:4]{index=4}

        // shift logic (normalized [0..1])
        const store = getShiftState(appSessionId, symbol);
        const ap = applyGfmShiftAndStreams(
          stats.bfm01, store.refGfm01, store.window, store.streams,
          { epsilonPct: epsPct, windowSize: kCycles, nowTs: last.ts, price: last.price }
        ); // normalized analytics. :contentReference[oaicite:5]{index=5}
        store.window  = ap.window;
        store.streams = ap.streams;
        if (ap.isShift) { store.refGfm01 = stats.bfm01; store.uiEpoch += 1; store.shifts += 1; }

        out[symbol] = {
          ok: true,
          window: windowKey,
          n: series.length,
          cards: {
            opening: { benchmark: opening, pct24h: t24.pct24h },
            live:    { benchmark: last.price, pct_drv: pctDrv(prev.price, last.price), pct24h: t24.pct24h },
          },
          stats, // full Stats from computeStats (includes gfmAbs/bfm01, vectors, inertia/amp/volt/efficiency). :contentReference[oaicite:6]{index=6}
          fm: {
            sigma: stats.sigma,
            zAbs:  stats.zAbs,
            inertia: stats.inertia, amp: stats.amp, volt: stats.volt, efficiency: stats.efficiency, // provided by metrics toolbox via stats.ts. :contentReference[oaicite:7]{index=7}
            nuclei: [], // optional: if you later expose nuclei from idhr frame, fill here
          },
          streams: store.streams,
          shifts: { nShifts: store.shifts, latestTs: last.ts },
          shift_stamp: ap.isShift,
          hist: { counts: makeCounts(series, opening, binsN) },
          extrema: { priceMin, priceMax, benchPctMin, benchPctMax },
          meta: { uiEpoch: store.uiEpoch, epsPct, kCycles },
          lastUpdateTs: last.ts,
        };
      } catch (e: any) {
        out[symbol] = { ok: false, error: String(e?.message ?? e) };
      }
    }

    return NextResponse.json({ ok: true, symbols, out, window: windowKey, ts: now });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: String(err?.message ?? err) }, { status: 500 });
  }
}
