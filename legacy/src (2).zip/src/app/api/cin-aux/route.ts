// src/app/api/cin-aux/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getAll as getSettings } from "@/lib/settings/server";
import { db } from "@/core/db";
import { fetch24hAll } from "@/core/sources/binance";
import { getAccountBalances } from "@/core/sources/binanceAccount";
import { saveCycleDocument } from "@/core/db/cycleDocuments";

export const dynamic = "force-dynamic";

// ------------------------- types -------------------------
type UiRow = {
  symbol: string;
  wallet_usdt: number;
  profit_usdt: number;
  session_imprint: number;
  session_luggage: number;
  cycle_imprint: number;
  cycle_luggage: number;
};

type CinRow = {
  imprint_cycle_usdt?: number | string | null;
  luggage_cycle_usdt?: number | string | null;
  imprint_app_session_usdt?: number | string | null;
  luggage_app_session_usdt?: number | string | null;
};

// ------------------------ helpers ------------------------
const norm = (s: string) => String(s || "").trim().toUpperCase();
const uniq = (a: string[]) => Array.from(new Set(a.filter(Boolean)));
const asNumber = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

function coinsFrom(qs: URLSearchParams, settingsCoins: string[]): string[] {
  const qCoins = (qs.get("coins") || "")
    .split(/[,\s]+/)
    .map(norm)
    .filter(Boolean);
  const base = qCoins.length ? qCoins : uniq((settingsCoins || []).map(norm));
  // safety fallback
  return base.length ? base : ["USDT", "BTC", "ETH"];
}

async function latestCycleTs(appSessionId: string): Promise<number | null> {
  try {
    const r = await db.query<{ ts: string | null }>(
      `select max(cycle_ts)::text as ts
         from cin_aux_cycle
        where app_session_id = $1`,
      [appSessionId],
    );
    const n = Number(r.rows?.[0]?.ts || 0);
    return Number.isFinite(n) && n > 0 ? n : null;
  } catch {
    return null;
  }
}

async function readCinView(appSessionId: string, cycleTs: number | null, coins: string[]): Promise<Map<string, CinRow>> {
  const map = new Map<string, CinRow>();
  if (!cycleTs) return map;
  try {
    const rx = coins.length ? `^(${coins.join("|")})$` : null;
    const args: Array<string | number> = [appSessionId, cycleTs];
    const sql = rx
      ? `select symbol,
                imprint_cycle_usdt,
                luggage_cycle_usdt,
                imprint_app_session_usdt,
                luggage_app_session_usdt
           from v_cin_aux
          where app_session_id = $1 and cycle_ts = $2 and symbol ~ $3
          order by symbol`
      : `select symbol,
                imprint_cycle_usdt,
                luggage_cycle_usdt,
                imprint_app_session_usdt,
                luggage_app_session_usdt
           from v_cin_aux
          where app_session_id = $1 and cycle_ts = $2
          order by symbol`;
    if (rx) args.push(rx);
    const r = await db.query(sql, args);
    for (const row of r.rows ?? []) {
      map.set(String((row as any)?.symbol ?? "").toUpperCase(), row as CinRow);
    }
  } catch {
    // ignore view errors; fall back to wallet-only rows
  }
  return map;
}

async function usdtPrices(bases: string[]): Promise<Record<string, number>> {
  const coins = uniq(bases.map(norm)).filter((c) => c && c !== "USDT");
  if (!coins.length) return { USDT: 1 };
  try {
    const symbols = coins.map((c) => `${c}USDT`);
    const tickers = await fetch24hAll(symbols);
    const out: Record<string, number> = { USDT: 1 };
    for (const t of tickers ?? []) {
      const sym = String((t as any)?.symbol ?? "");
      const base = sym.replace(/USDT$/i, "");
      const price = asNumber((t as any)?.lastPrice ?? (t as any)?.weightedAvgPrice);
      if (base) out[base] = price;
    }
    return out;
  } catch {
    return { USDT: 1 };
  }
}

// --------------------------- GET ---------------------------
export async function GET(req: NextRequest) {
  const qs = req.nextUrl.searchParams;

  try {
    const settings = await getSettings().catch(() => ({ coinUniverse: [] as string[] }));
    const coins = coinsFrom(qs, settings.coinUniverse ?? []);
    const appSessionId = (qs.get("appSessionId") || process.env.NEXT_PUBLIC_APP_SESSION_ID || process.env.APP_SESSION_ID || "dev-01").slice(0, 64);

    const [ts, walletRaw, prices, cinBySym] = await Promise.all([
      latestCycleTs(appSessionId),
      getAccountBalances().catch(() => ({} as Record<string, number>)),
      usdtPrices(coins).catch(() => ({ USDT: 1 } as Record<string, number>)),
      readCinView(appSessionId, await latestCycleTs(appSessionId), coins), // read view with freshest ts
    ]);

    const rows: UiRow[] = coins.map((sym) => {
      const qty = asNumber((walletRaw as Record<string, unknown>)?.[sym]);
      const px = asNumber(prices?.[sym] ?? (sym === "USDT" ? 1 : 0));
      const cin = cinBySym.get(sym) ?? {};
      return {
        symbol: sym,
        wallet_usdt: qty * px,
        profit_usdt: 0, // can be filled from realized P/L view when ready
        session_imprint: asNumber(cin.imprint_app_session_usdt),
        session_luggage: asNumber(cin.luggage_app_session_usdt),
        cycle_imprint: asNumber(cin.imprint_cycle_usdt),
        cycle_luggage: asNumber(cin.luggage_cycle_usdt),
      };
    });

    // docs (non-blocking; feature-flag safe in helper)
    try {
      await saveCycleDocument({
        domain: "cin",
        appSessionId,
        cycleTs: Number(ts) || Date.now(),
        payload: { ok: true, coins, rows, cycleTs: ts, ts: Date.now() },
        rowsCount: rows.length,
        notes: "api:cin-aux",
      });
    } catch {}

    return NextResponse.json(
      { ok: true, coins, rows, cycleTs: ts, ts: Date.now() },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (err: any) {
    // keep endpoint alive with a soft failure (200 + ok:false) to avoid breaking smokes
    return NextResponse.json(
      { ok: false, error: String(err?.message ?? err) },
      { headers: { "Cache-Control": "no-store" } },
    );
  }
}
