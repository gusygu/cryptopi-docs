// src/app/str-aux/StrAuxClient.tsx
'use client';

import React from 'react';

/* ---------- Types that match /api/str-aux/stats ---------- */
type WindowKey = '30m' | '1h' | '3h';

type SymStamp = { ts: number; price: number; gfm?: number; deltaPct?: number };
type Tendency = { direction: number; strength: number; slope: number; r: number; score: number };
type StatRow = {
  sigma: number; zAbs: number;

  // FloMo (abs) + BFloM (0..1)
  gfmAbs: number; refGfmAbs: number; deltaGfmAbs: number; deltaGfmPct: number; shiftedGfm: boolean;
  bfm01: number; refBfm01: number; deltaBfm01: number; deltaBfmPct: number; shiftedBfm: boolean;

  // vectors
  vInner: number; vOuter: number; tendency: Tendency;
  vSwap?: { Q: number; score: number; q1: number; q3: number } | null;

  // toolbox (optional)
  inertia?: { static: number; growth: number; total: number; face: 'static'|'growth' };
  amp?: number; volt?: number; efficiency?: number;

  // raw helpers
  opening: number; last: number; prev: number;
};
type ApiOut = {
  ok: boolean;
  symbols: string[];
  window: WindowKey;
  ts: number;
  out: {
    [symbol: string]: {
      ok: boolean; error?: string; window: WindowKey; n: number;
      cards?: {
        opening: { benchmark: number; pct24h?: number };
        live:    { benchmark: number; pct_drv?: number; pct24h?: number };
      };
      stats?: StatRow;
      extrema?: { priceMin?: number; priceMax?: number; benchPctMin?: number; benchPctMax?: number };
      streams?: { stamps?: SymStamp[]; maxStamps?: number };
      shifts?: { nShifts: number; latestTs: number };
      hist?: { counts: number[] };
      meta?: { uiEpoch: number; epsPct: number; kCycles: number };
      lastUpdateTs?: number;
      db_error?: string;
    };
  };
};

/* ---------- helpers ---------- */
const U = (s: unknown) => String(s ?? '').trim().toUpperCase();
const KNOWN_QUOTES = ['USDT','BTC','ETH','BNB','BUSD','FDUSD','USDC','TUSD'] as const;
function splitSymbol(sym: string): { base: string; quote: string } {
  const S = U(sym);
  for (const q of KNOWN_QUOTES) if (S.endsWith(q) && S.length > q.length) return { base: S.slice(0, -q.length), quote: q };
  return { base: S.replace(/USDT$/i, ''), quote: 'USDT' };
}
const uniq = <T,>(xs: T[]) => Array.from(new Set(xs));
const fmtNum = (n?: number) => (Number.isFinite(n as number) ? (n as number).toLocaleString(undefined, { maximumFractionDigits: 6 }) : '—');
const fmtPct = (n?: number) => (Number.isFinite(n as number) ? `${(n as number)>=0?'+':''}${(n as number).toFixed(2)}%` : '—');

function cardStyle(bg: string, border: string): React.CSSProperties {
  return {
    padding: 12,
    borderRadius: 10,
    background: bg,
    border: `1px solid ${border}`,
  };
}

/* ---------- Controls (was missing) ---------- */
function Controls(props: {
  windowKey: WindowKey; setWindowKey: (v: WindowKey) => void;
  bins: number; setBins: (n: number) => void;
  sessionId: string; setSessionId: (v: string) => void;
  epsPct: number; setEpsPct: (n: number) => void;
  kCycles: number; setKCycles: (n: number) => void;
}) {
  const { windowKey, setWindowKey, bins, setBins, sessionId, setSessionId, epsPct, setEpsPct, kCycles, setKCycles } = props;

  return (
    <div style={{
      display: 'grid', gap: 10, padding: 12, borderRadius: 8,
      border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.02)'
    }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 10 }}>
        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ fontSize: 12, opacity: 0.8 }}>window</span>
          <select
            value={windowKey}
            onChange={(e) => setWindowKey(e.target.value as WindowKey)}
            style={{ padding: '6px 8px', background: '#0e1320', border: '1px solid #2a3350', borderRadius: 6, color: '#e5e7eb' }}
          >
            <option value="30m">30m</option>
            <option value="1h">1h</option>
            <option value="3h">3h</option>
          </select>
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ fontSize: 12, opacity: 0.8 }}>bins</span>
          <input
            type="number" min={16} max={1024} step={1} value={bins}
            onChange={(e) => setBins(Math.max(16, Math.min(1024, Math.floor(Number(e.target.value) || 128))))}
            style={{ padding: '6px 8px', background: '#0e1320', border: '1px solid #2a3350', borderRadius: 6, color: '#e5e7eb' }}
          />
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ fontSize: 12, opacity: 0.8 }}>session id</span>
          <input
            type="text" value={sessionId} onChange={(e) => setSessionId(e.target.value.slice(0, 64))}
            placeholder="dev-01"
            style={{ padding: '6px 8px', background: '#0e1320', border: '1px solid #2a3350', borderRadius: 6, color: '#e5e7eb' }}
          />
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ fontSize: 12, opacity: 0.8 }}>ε (ΔGFM %)</span>
          <input
            type="number" step="0.01" min="0.01" max="5" value={epsPct}
            onChange={(e) => setEpsPct(Math.max(0.01, Math.min(5, Number(e.target.value) || 0.35)))}
            style={{ padding: '6px 8px', background: '#0e1320', border: '1px solid '#2a3350', borderRadius: 6, color: '#e5e7eb' }}
          />
        </label>
        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ fontSize: 12, opacity: 0.8 }}>k cycles</span>
          <input
            type="number" min={1} max={12} value={kCycles}
            onChange={(e) => setKCycles(Math.max(1, Math.min(12, Math.floor(Number(e.target.value) || 5))))}
            style={{ padding: '6px 8px', background: '#0e1320', border: '1px solid #2a3350', borderRadius: 6, color: '#e5e7eb' }}
          />
        </label>
      </div>
    </div>
  );
}

/* ---------- light toggles ---------- */
function Pill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '6px 10px', borderRadius: 999,
        border: `1px solid ${active ? '#93c5fd' : 'rgba(255,255,255,0.12)'}`,
        background: active ? 'rgba(147,197,253,0.08)' : 'transparent',
        color: active ? '#dbeafe' : '#e5e7eb',
        cursor: 'pointer'
      }}
    >{children}</button>
  );
}
function CoinToggles(props: {
  universe: string[]; suggested: string[]; selected: string[]; setSelected: (v: string[]) => void; loading?: boolean; title: string;
}) {
  const { universe, suggested, selected, setSelected, loading, title } = props;
  const bases = (suggested.length ? suggested : universe).sort();
  return (
    <div style={{ display: 'grid', gap: 8 }}>
      <div style={{ fontSize: 12, opacity: 0.8 }}>{title}</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {loading ? <span style={{ opacity: 0.7 }}>loading…</span> :
          bases.map(b => (
            <Pill key={b} active={selected.includes(b)} onClick={() => {
              setSelected(selected.includes(b) ? selected.filter(x => x !== b) : [...selected, b]);
            }}>{b}</Pill>
          ))
        }
      </div>
    </div>
  );
}
function SymbolToggles(props: {
  pool: string[]; selected: string[]; setSelected: (v: string[]) => void; title: string;
}) {
  const { pool, selected, setSelected, title } = props;
  const syms = pool.sort();
  return (
    <div style={{ display: 'grid', gap: 8 }}>
      <div style={{ fontSize: 12, opacity: 0.8 }}>{title}</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {syms.map(s => (
          <Pill key={s} active={selected.includes(s)} onClick={() => {
            setSelected(selected.includes(s) ? selected.filter(x => x !== s) : [...selected, s]);
          }}>{s}</Pill>
        ))}
      </div>
    </div>
  );
}

/* ---------- small UI atoms ---------- */
function KV({ label, value, accent, tone }: { label: string; value: React.ReactNode; accent?: boolean; tone?: 'good'|'muted' }) {
  const color = tone === 'good' ? '#67e8f9' : tone === 'muted' ? 'rgba(229,231,235,0.6)' : '#e5e7eb';
  return (
    <div style={{ display: 'grid', gap: 2 }}>
      <div style={{ fontSize: 11, opacity: 0.7 }}>{label}</div>
      <div style={{ fontSize: accent ? 14 : 13, fontWeight: accent ? 600 : 500, color }}>{value}</div>
    </div>
  );
}
function MiniBars({ counts }: { counts: number[] }) {
  if (!counts?.length) return null;
  const mx = Math.max(...counts);
  return (
    <div style={{ display: 'flex', gap: 2, height: 32, alignItems: 'flex-end', opacity: 0.8 }}>
      {counts.map((c, i) => {
        const h = mx > 0 ? (c / mx) * 32 : 0;
        return <div key={i} style={{ width: 3, height: h, background: 'rgba(148,163,184,0.7)', borderRadius: 1 }} />;
      })}
    </div>
  );
}
function StreamsTable({ stamps }: { stamps?: SymStamp[] }) {
  if (!stamps?.length) return null;
  return (
    <div style={cardStyle('#0f172a', '#2a3350')}>
      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 6 }}>streams</div>
      <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr 1fr', gap: 6, fontSize: 12 }}>
        <div style={{ opacity: 0.6 }}>ts</div>
        <div style={{ opacity: 0.6 }}>price</div>
        <div style={{ opacity: 0.6 }}>Δ%</div>
        {stamps.slice(-12).map((s, i) => (
          <React.Fragment key={i}>
            <div>{new Date(s.ts).toLocaleTimeString()}</div>
            <div>{fmtNum(s.price)}</div>
            <div>{fmtPct(s.deltaPct)}</div>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

/* ---------- data hooks ---------- */
function usePreviewUniverse() {
  const [universeSymbols, setUniverseSymbols] = React.useState<string[]>([]);
  const [settingsSymbols, setSettingsSymbols] = React.useState<string[]>([]);
  const [loading, setLoading] = React.useState(true);

  const pluckSymbols = React.useCallback((j: any): string[] => {
    if (Array.isArray(j)) return j.filter(Boolean).map(U);
    if (Array.isArray(j?.symbols)) return j.symbols.filter(Boolean).map(U);
    if (Array.isArray(j?.pairs)) return j.pairs.map((p: any) => (typeof p === 'string' ? p : p?.symbol ?? p?.pair ?? p?.s)).filter(Boolean).map(U);
    if (Array.isArray(j?.list))  return j.list .map((p: any) => (typeof p === 'string' ? p : p?.symbol ?? p?.pair ?? p?.s)).filter(Boolean).map(U);
    if (j && typeof j === 'object') {
      const all: string[] = [];
      for (const k of Object.keys(j)) {
        const v = (j as any)[k];
        if (Array.isArray(v)) for (const item of v) {
          const s = typeof item === 'string' ? item : item?.symbol ?? item?.pair ?? item?.s;
          if (s) all.push(U(s));
        }
      }
      if (all.length) return all;
    }
    return [];
  }, []);

  React.useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setLoading(true);
        const r1 = await fetch('/api/market/preview', { cache: 'no-store' });
        const j1 = await r1.json().catch(() => ({}));
        const sym1 = pluckSymbols(j1);

        const r2 = await fetch('/api/market/preview/symbols', { cache: 'no-store' });
        const j2 = await r2.json().catch(() => ({}));
        const sym2 = pluckSymbols(j2);

        if (!alive) return;
        setUniverseSymbols(sym1);
        setSettingsSymbols(sym2);
      } catch {
        if (!alive) return;
        setUniverseSymbols([]); setSettingsSymbols([]);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [pluckSymbols]);

  const basesSettings = React.useMemo(() => uniq(settingsSymbols.map(s => splitSymbol(s).base)), [settingsSymbols]);
  const basesUniverse  = React.useMemo(() => uniq(universeSymbols .map(s => splitSymbol(s).base)), [universeSymbols]);

  return { universeSymbols, settingsSymbols, basesUniverse, basesSettings, loading };
}

function useStats(params: {
  windowKey: WindowKey; bins: number; sessionId: string;
  bases?: string[]; symbols?: string[]; epsPct?: number; kCycles?: number; refreshMs?: number;
}) {
  const [data, setData] = React.useState<ApiOut | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [err, setErr] = React.useState<string | null>(null);

  const query = React.useMemo(() => {
    const p = new URLSearchParams();
    p.set('window', params.windowKey);
    p.set('bins', String(params.bins));
    p.set('sessionId', params.sessionId);
    if (params.symbols?.length) p.set('symbols', params.symbols.join(','));
    else if (params.bases?.length) p.set('bases', params.bases.join(','));
    if (params.epsPct != null) p.set('eps', String(params.epsPct));
    if (params.kCycles != null) p.set('k', String(params.kCycles));
    return p.toString();
  }, [params.windowKey, params.bins, params.sessionId, params.bases, params.symbols, params.epsPct, params.kCycles]);

  React.useEffect(() => {
    let alive = true;
    async function run() {
      try {
        setLoading(true); setErr(null);
        const r = await fetch(`/api/str-aux/stats?${query}`, { cache: 'no-store' });
        const j = (await r.json()) as ApiOut;
        if (!alive) return;
        if (!r.ok || !j?.ok) { setErr((j as any)?.error ?? `HTTP ${r.status}`); setData(null); }
        else { setData(j); }
      } catch (e: any) { if (alive) { setErr(e?.message ?? String(e)); setData(null); } }
      finally { if (alive) setLoading(false); }
    }
    run();
    const t = setInterval(run, Math.max(2000, params.refreshMs ?? 7000));
    return () => { alive = false; clearInterval(t); };
  }, [query, params.refreshMs]);

  return { data, loading, err };
}

/* ---------- main component ---------- */
export default function StrAuxClient() {
  const [windowKey, setWindowKey] = React.useState<WindowKey>('30m');
  const [bins, setBins] = React.useState(128);
  const [sessionId, setSessionId] = React.useState('dev-01');
  const [epsPct, setEpsPct] = React.useState(0.35);
  const [kCycles, setKCycles] = React.useState(5);

  const { universeSymbols, basesUniverse, basesSettings, loading: loadingPrev } = usePreviewUniverse();

  const [selectedBases, setSelectedBases] = React.useState<string[]>([]);
  React.useEffect(() => {
    const saved = localStorage.getItem('STR_AUX_SELECTED_BASES');
    const cached = saved ? (JSON.parse(saved) as string[]) : null;
    if (basesSettings.length) setSelectedBases(cached?.length ? [...new Set(cached.map(U).filter(b => basesSettings.includes(b)))] : basesSettings);
    else if (cached?.length) setSelectedBases([...new Set(cached.map(U))]);
    else setSelectedBases([]);
  }, [basesSettings]);
  React.useEffect(() => { localStorage.setItem('STR_AUX_SELECTED_BASES', JSON.stringify(selectedBases)); }, [selectedBases]);

  const [selectedSymbols, setSelectedSymbols] = React.useState<string[]>([]);
  React.useEffect(() => {
    const saved = localStorage.getItem('STR_AUX_SELECTED_SYMBOLS');
    const cached = saved ? (JSON.parse(saved) as string[]) : null;
    const pool = universeSymbols
      .filter(s => basesSettings.includes(splitSymbol(s).base))
      .filter(s => selectedBases.includes(splitSymbol(s).base));
    const initial = cached?.length ? [...new Set(cached.map(U).filter(s => pool.includes(s)))] : [...new Set(pool)];
    setSelectedSymbols(initial);
  }, [universeSymbols, basesSettings, selectedBases]);
  React.useEffect(() => { localStorage.setItem('STR_AUX_SELECTED_SYMBOLS', JSON.stringify(selectedSymbols)); }, [selectedSymbols]);

  const { data, loading, err } = useStats({
    windowKey, bins, sessionId,
    symbols: selectedSymbols.length ? selectedSymbols : undefined,
    bases: !selectedSymbols.length && selectedBases.length ? selectedBases : undefined,
    epsPct, kCycles, refreshMs: 7000,
  });

  const symbols = data?.symbols ?? [];
  const out = data?.out ?? {};

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <Controls
        windowKey={windowKey} setWindowKey={setWindowKey}
        bins={bins} setBins={setBins}
        sessionId={sessionId} setSessionId={(v) => { const x = v.slice(0,64); setSessionId(x); localStorage.setItem('APP_SESSION_ID', x); }}
        epsPct={epsPct} setEpsPct={setEpsPct}
        kCycles={kCycles} setKCycles={setKCycles}
      />

      <CoinToggles
        universe={basesUniverse}
        suggested={basesSettings.length ? basesSettings : basesUniverse}
        selected={selectedBases}
        setSelected={setSelectedBases}
        loading={loadingPrev}
        title="coins"
      />

      <SymbolToggles
        pool={universeSymbols
          .filter(s => basesSettings.includes(splitSymbol(s).base))
          .filter(s => selectedBases.includes(splitSymbol(s).base))}
        selected={selectedSymbols}
        setSelected={setSelectedSymbols}
        title="symbols"
      />

      {err && <div style={cardStyle('#3b1d1d', '#fca5a5')}><b>error</b>: {err}</div>}
      {(loading || loadingPrev) && <div style={{ opacity: 0.8, fontSize: 13 }}>loading…</div>}
      {!loading && !loadingPrev && symbols.length === 0 && <div style={{ opacity: 0.8, fontSize: 13 }}>no symbols — adjust toggles</div>}

      <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', alignItems: 'stretch' }}>
        {symbols.map((sym) => <SymbolPanel key={sym} sym={sym} row={out[sym]} />)}
      </div>
    </div>
  );
}

/* ---------- symbol card ---------- */
function SymbolPanel({ sym, row }: { sym: string; row: ApiOut['out'][string] | undefined }) {
  if (!row) return <div style={cardStyle('#281a1a', '#eab308')}><strong>{sym}</strong><div style={{ opacity: 0.75, fontSize: 12 }}>no data</div></div>;
  if (!row.ok) return (
    <div style={cardStyle('#281a1a', '#eab308')}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <strong>{sym}</strong><span style={{ opacity: 0.7 }}>{row?.error ?? 'unavailable'}</span>
      </div>
    </div>
  );

  const open = row.cards?.opening;
  const live = row.cards?.live;
  const ex = row.extrema ?? {};
  const t24 = row.cards?.opening?.pct24h ?? undefined;

  const vInner = row.stats?.vInner ?? 0;
  const vOuter = row.stats?.vOuter ?? 0;
  const vSwap  = row.stats?.vSwap ?? null;

  const gfmAbs = row.stats?.gfmAbs;
  const dPct   = row.stats?.deltaGfmPct;
  const shifted = !!row.stats?.shiftedGfm;

  const gfmStr = Number.isFinite(gfmAbs as number)
    ? `${fmtNum(gfmAbs)}${Number.isFinite(dPct as number) ? ` (${(dPct as number) >= 0 ? '+' : ''}${(dPct as number).toFixed(2)}%)` : ''}`
    : '—';

  return (
    <div style={cardStyle(shifted ? '#112530' : '#151a24', shifted ? '#67e8f9' : '#a5b4fc')}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <strong style={{ fontSize: 16 }}>{sym}</strong>
        <div style={{ fontSize: 12, opacity: 0.75 }}>{row.window} · {row.n} pts</div>
      </div>

      <div style={{ marginTop: 10, display: 'grid', gap: 8 }}>
        <KV label="GFM (Δ%)" value={gfmStr} accent />

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
          <KV label="price" value={fmtNum(live?.benchmark)} />
          <KV label="24h" value={fmtPct(t24)} />
          <KV label="drv" value={fmtPct(live?.pct_drv)} />
          <KV label="shift" value={shifted ? 'yes' : 'no'} tone={shifted ? 'good' : 'muted'} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8 }}>
          <KV label="opening" value={fmtNum(open?.benchmark)} />
          <KV label="min" value={fmtNum(ex.priceMin)} />
          <KV label="max" value={fmtNum(ex.priceMax)} />
          <KV label="σ" value={fmtNum(row.stats?.sigma)} />
          <KV label="|z|" value={fmtNum(row.stats?.zAbs)} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
          <KV label="vInner" value={fmtNum(vInner)} />
          <KV label="vOuter" value={fmtNum(vOuter)} />
          {row.stats?.tendency && <KV label="vTendency" value={fmtNum(row.stats.tendency.score)} />}
          {vSwap && <KV label="vSwap" value={`${fmtNum(vSwap.score)} (Q=${fmtNum(vSwap.Q)})`} />}
        </div>

        {row.hist?.counts?.length ? <MiniBars counts={row.hist!.counts} /> : null}
        <StreamsTable stamps={row.streams?.stamps} />

        {row.db_error && (
          <div style={cardStyle('#3b1d1d', '#ef4444')}>
            <div style={{ fontSize: 12, opacity: 0.8 }}>db_error: {row.db_error}</div>
          </div>
        )}
      </div>
    </div>
  );
}
