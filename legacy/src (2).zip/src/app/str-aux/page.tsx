"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

import Histogram from "@/components/features/str-aux/Histogram";
import CoinPanel from "@/components/features/str-aux/CoinPanel";
import { useSettings } from "@/lib/settings/provider";
import { crossPairsFromCoins, dedupeCoins, usdtLegsFromCoins } from "@/lib/markets/pairs";

type WindowSel = "30m" | "1h" | "3h";
type PairAvailability = { usdt: string[]; cross: string[]; all: string[] };

type FM = {
  gfm?: number;
  sigma?: number;
  zAbs?: number;
  vInner?: number;
  vOuter?: number;
  inertia?: number;
  disruption?: number;
  nuclei?: { binIndex: number }[];
  gfm_ref_price?: number;
  gfm_calc_price?: number;
};
type Hist = { counts: number[] };
type CoinOut = {
  ok: boolean;
  n?: number;
  window?: string;
  bins?: number;
  cards?: {
    opening?: { benchmark?: number; pct24h?: number };
    live?: { benchmark?: number; pct24h?: number; pct_drv?: number };
  };
  fm?: FM;
  hist?: Hist;
  error?: string;
};
type BinsResponse = {
  ok: boolean;
  ts: number;
  symbols: string[];
  out: Record<string, CoinOut>;
  available?: PairAvailability;
  selected?: string[];
  timing?: { autoRefreshMs?: number; secondaryEnabled?: boolean; secondaryCycles?: number };
};

const DEFAULT_COINS = ["BTC", "ETH", "BNB", "SOL", "ADA", "XRP", "DOGE", "USDT"];

const uniqUpper = (xs: string[]) => {
  const set = new Set<string>();
  const out: string[] = [];
  for (const raw of xs) {
    const val = String(raw ?? "").trim().toUpperCase();
    if (!val || set.has(val)) continue;
    set.add(val);
    out.push(val);
  }
  return out;
};

const CHIP_BASE = "rounded-full border px-3 py-1 text-xs transition-colors";
const CHIP_ACTIVE = "border-emerald-400/70 text-emerald-100 bg-emerald-500/15 shadow-[0_0_12px_rgba(16,185,129,0.25)]";
const CHIP_PASSIVE = "border-white/15 text-white/70 hover:border-white/40";
const CHIP_DISABLED = "border-white/10 text-white/30 cursor-not-allowed";

export default function StrAuxPage() {
  const { settings } = useSettings();

  const baseMs = Math.max(1000, Number(settings?.timing?.autoRefreshMs ?? 40_000));
  const secondaryEnabled = !!settings?.timing?.secondaryEnabled;
  const secondaryCycles = Math.max(1, Math.min(10, Number(settings?.timing?.secondaryCycles ?? 3)));

  const bases = useMemo(
    () => {
      const source = settings?.coinUniverse?.length ? settings.coinUniverse : DEFAULT_COINS;
      const normalized = dedupeCoins(source);
      return normalized.length ? normalized : dedupeCoins(DEFAULT_COINS);
    },
    [settings?.coinUniverse?.join(",")],
  );

  const [pickedCoins, setPickedCoins] = useState<string[]>(bases);
  useEffect(() => setPickedCoins(bases), [bases.join(",")]);

  const [windowSel, setWindowSel] = useState<WindowSel>("30m");
  const [auto, setAuto] = useState(true);

  const [availableApi, setAvailableApi] = useState<PairAvailability>({ usdt: [], cross: [], all: [] });
  const [availableUi, setAvailableUi] = useState<PairAvailability>({ usdt: [], cross: [], all: [] });

  const [pairs, setPairs] = useState<string[]>([]);

  const [data, setData] = useState<BinsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const [includeCross, setIncludeCross] = useState(false);
  const [hideNoData, setHideNoData] = useState(true);

  useEffect(() => {
    const coins = pickedCoins.length ? pickedCoins : bases;
    const usdt = usdtLegsFromCoins(coins);
    const cross = crossPairsFromCoins(coins);
    const all = uniqUpper([...usdt, ...cross]);
    setAvailableUi({ usdt, cross, all });
    if (!pairs.length && usdt.length) setPairs(usdt);
  }, [pickedCoins.join(","), bases.join(","), pairs.length]);

  const availableUX = useMemo(() => {
    const usdt = (availableApi.usdt.length ? availableApi.usdt : availableUi.usdt) ?? [];
    const crossCandidates = uniqUpper([...(availableUi.cross ?? []), ...(availableApi.cross ?? [])]);
    const allCandidates = uniqUpper([
      ...(availableUi.all ?? []),
      ...(availableApi.all ?? []),
      ...usdt,
      ...crossCandidates,
    ]);
    const crossActive = includeCross ? crossCandidates : [];
    const allActive = includeCross ? uniqUpper([...usdt, ...crossActive]) : usdt;
    return {
      usdt,
      cross: crossActive,
      crossCandidates,
      all: allActive,
      allCandidates,
    };
  }, [availableApi, availableUi, includeCross]);

  useEffect(() => {
    if (!pairs.length) return;
    const allowed = new Set(availableUX.all);
    setPairs((prev) => prev.filter((pair) => allowed.has(pair)));
  }, [availableUX.all.join(","), pairs.length]);

  const fetchOnce = useCallback(
    async (opts?: { signal?: AbortSignal }) => {
      setLoading(true);
      setErr(null);
      try {
        const qs = new URLSearchParams();
        if (pairs.length) qs.set("pairs", pairs.join(","));
        qs.set("window", windowSel);
        if (includeCross) qs.set("allowUnverified", "1");
        if (hideNoData) qs.set("hideNoData", "1");

        const res = await fetch(`/api/str-aux/bins?${qs.toString()}`, { cache: "no-store", signal: opts?.signal });
        const text = await res.text();
        let parsed: BinsResponse;
        try {
          parsed = JSON.parse(text) as BinsResponse;
        } catch {
          const snippet = text.slice(0, 140).replace(/\s+/g, " ");
          throw new Error(`${res.status} ${res.statusText} — ${snippet}`);
        }
        if (!res.ok || !parsed?.ok) throw new Error((parsed as any)?.error ?? `HTTP ${res.status}`);

        setData(parsed);
        if (parsed?.available) setAvailableApi(parsed.available);
      } catch (e: any) {
        if (e?.name === "AbortError") return;
        setErr(String(e?.message ?? e));
        setData(null);
      } finally {
        setLoading(false);
      }
    },
    [pairs.join(","), windowSel, includeCross, hideNoData],
  );

  useEffect(() => {
    const controller = new AbortController();
    fetchOnce({ signal: controller.signal });
    if (timer.current) {
      clearInterval(timer.current);
      timer.current = null;
    }
    if (auto) {
      const period = Math.max(10_000, baseMs) * (secondaryEnabled ? Math.max(1, secondaryCycles) : 1);
      timer.current = setInterval(() => fetchOnce({ signal: controller.signal }), period);
    }
    return () => {
      controller.abort();
      if (timer.current) clearInterval(timer.current);
    };
  }, [fetchOnce, auto, baseMs, secondaryEnabled, secondaryCycles]);

  const coinRows = useMemo(() => Object.keys(data?.out ?? {}), [data?.out]);
  const rows = coinRows
    .map((sym) => ({ sym, out: data?.out?.[sym] }))
    .filter(({ out }) => (hideNoData ? !!out?.ok : true));

  const counts = {
    usdt: availableUX.usdt.length,
    crossActive: availableUX.cross.length,
    crossTotal: availableUX.crossCandidates.length,
    selected: pairs.length,
    total: availableUX.allCandidates.length,
  };

  const toggleCoin = useCallback((coin: string) => {
    setPickedCoins((prev) => (prev.includes(coin) ? prev.filter((c) => c !== coin) : uniqUpper([...prev, coin])));
  }, []);

  const togglePair = useCallback((pair: string) => {
    setPairs((prev) => (prev.includes(pair) ? prev.filter((p) => p !== pair) : uniqUpper([...prev, pair])));
  }, []);

  const selectUsdtLegs = useCallback(() => setPairs([...availableUX.usdt]), [availableUX.usdt]);
  const selectAllActive = useCallback(() => setPairs([...availableUX.all]), [availableUX.all]);
  const clearPairs = useCallback(() => setPairs([]), []);

  const usdtSymbols = useMemo(() => [...availableUX.usdt].sort(), [availableUX.usdt.join(",")]);
  const crossCandidates = useMemo(
    () => [...availableUX.crossCandidates].sort(),
    [availableUX.crossCandidates.join(",")],
  );

  const renderSymbolChip = useCallback(
    (symbol: string, disabled: boolean) => {
      const active = pairs.includes(symbol);
      const classes = [
        CHIP_BASE,
        active ? CHIP_ACTIVE : disabled ? CHIP_DISABLED : CHIP_PASSIVE,
      ].join(" ");
      return (
        <button
          key={symbol}
          className={classes}
          disabled={disabled}
          onClick={() => {
            if (disabled) return;
            togglePair(symbol);
          }}
          type="button"
        >
          {symbol}
        </button>
      );
    },
    [pairs, togglePair],
  );

  return (
    <div className="min-h-screen bg-[#050914] text-white">
      <div className="mx-auto flex w-full max-w-[1400px] flex-col gap-6 px-4 py-6">
        <header className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight">STR-AUX · Live Stats</h1>
            <div className="ml-auto flex items-center gap-2">
              <button
                className="rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm text-white hover:border-white/40"
                disabled={loading}
                onClick={() => fetchOnce()}
                type="button"
              >
                {loading ? "Syncing…" : "Refresh"}
              </button>
              <button
                className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                  auto
                    ? "border-emerald-400/70 bg-emerald-500/15 text-emerald-100"
                    : "border-white/20 bg-white/5 text-white/70 hover:border-white/40"
                }`}
                onClick={() => setAuto((v) => !v)}
                type="button"
              >
                Auto {auto ? "ON" : "OFF"}
              </button>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-[auto_auto_1fr] md:items-center">
            <div className="flex items-center gap-2">
              <span className="cp-pill">Window</span>
              {(["30m", "1h", "3h"] as WindowSel[]).map((option) => (
                <button
                  key={option}
                  className={`btn text-xs ${option === windowSel ? "btn-emerald" : "btn-silver"}`}
                  onClick={() => setWindowSel(option)}
                  type="button"
                >
                  {option}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <label className="cp-pill-silver inline-flex items-center gap-2">
                <input
                  checked={hideNoData}
                  onChange={(event) => setHideNoData(event.target.checked)}
                  type="checkbox"
                />
                hide empty
              </label>
              <button
                className={`rounded-full border px-3 py-1 text-xs transition-colors ${
                  includeCross
                    ? "border-emerald-400/70 bg-emerald-500/15 text-emerald-100"
                    : "border-white/20 bg-white/5 text-white/70 hover:border-white/40"
                }`}
                onClick={() => setIncludeCross((v) => !v)}
                type="button"
              >
                Cross combos {includeCross ? "ON" : "OFF"}
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-white/60">
              <span className="cp-pill-silver">USDT <b>{counts.usdt}</b></span>
              <span className="cp-pill-silver">Cross <b>{counts.crossActive}/{counts.crossTotal}</b></span>
              <span className="cp-pill-silver">Universe <b>{counts.total}</b></span>
              <span className="cp-pill-silver">Selected <b>{counts.selected}</b></span>
            </div>
          </div>

          {err && (
            <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {err}
            </div>
          )}
        </header>

        <section className="cp-card space-y-4">
          <div>
            <div className="text-xs uppercase tracking-wide text-white/60">Coins</div>
            <div className="mt-2 flex flex-wrap gap-2">
              {bases.map((coin) => {
                const active = pickedCoins.includes(coin);
                return (
                  <button
                    key={coin}
                    className={`btn text-xs ${active ? "btn-emerald" : "btn-silver"}`}
                    onClick={() => toggleCoin(coin)}
                    type="button"
                  >
                    {coin}
                  </button>
                );
              })}
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-white/50">
              <span>{pickedCoins.length}/{bases.length} selected</span>
              <button className="underline-offset-2 hover:underline" onClick={() => setPickedCoins(bases)} type="button">
                all
              </button>
              <button className="underline-offset-2 hover:underline" onClick={() => setPickedCoins([])} type="button">
                clear
              </button>
            </div>
          </div>

          <div className="h-px bg-white/10" />

          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-xs uppercase tracking-wide text-white/60">Symbols</div>
              <div className="ml-auto flex flex-wrap items-center gap-2 text-[11px] text-white/50">
                <button className="underline-offset-2 hover:underline" onClick={selectUsdtLegs} type="button">
                  USDT legs
                </button>
                <button className="underline-offset-2 hover:underline" onClick={selectAllActive} type="button">
                  all active
                </button>
                <button className="underline-offset-2 hover:underline" onClick={clearPairs} type="button">
                  clear
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {usdtSymbols.map((symbol) => renderSymbolChip(symbol, false))}
              {!usdtSymbols.length && (
                <span className="text-xs text-white/40">No USDT legs for current selection.</span>
              )}
            </div>

            <div>
              <div className="mt-2 text-[11px] uppercase tracking-wide text-white/45">Cross combinations</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {crossCandidates.map((symbol) => renderSymbolChip(symbol, !includeCross))}
                {!crossCandidates.length && (
                  <span className="text-xs text-white/40">Add more bases to form cross pairs.</span>
                )}
                {!includeCross && crossCandidates.length > 0 && (
                  <span className="text-[11px] text-white/50">Enable cross combos to activate these pairs.</span>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {rows.slice(0, 12).map(({ sym, out }) => (
            <CoinPanel key={sym} symbol={sym} coin={out as any} epochTs={data?.ts ?? 0} windowSel={windowSel} />
          ))}
          {!rows.length && (
            <div className="cp-card text-sm text-white/60">No data yet – adjust coin selection or enable cross combos.</div>
          )}
        </section>

        <section className="cp-card">
          <div className="text-xs text-white/60">Population histogram</div>
          <div className="mt-2">
            <Histogram
              counts={rows[0]?.out?.hist?.counts ?? []}
              height={120}
              nuclei={(rows[0]?.out?.fm?.nuclei ?? []).map((n) => n.binIndex)}
            />
          </div>
        </section>
      </div>
    </div>
  );
}
